import 'package:electricity_collectors_app/providers/payment_provider.dart';
import 'package:electricity_collectors_app/providers/reading_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart'; // 1. استدعاء مكتبة Supabase

import 'providers/reports_provider.dart';
import 'providers/sync_provider.dart';
import 'providers/customer_provider.dart';
import 'providers/auth_provider.dart';
import 'features/splash_screen.dart';

void main() async {
  // 2. تحويل الدالة إلى async لضمان الانتظار
  WidgetsFlutterBinding.ensureInitialized();

  // 3. تهيئة Supabase كخطوة أولى وحاسمة قبل تشغيل أي شيء
  await Supabase.initialize(
    url: 'https://nnzzwjzhdlyocwfgwovl.supabase.co',
    publishableKey: 'sb_publishable_C-QnmlF8rwfOKfyeT8l6LQ_EBaUAdCK',
  );

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => SyncProvider()),
        ChangeNotifierProvider(create: (_) => CustomerProvider()),
        ChangeNotifierProvider(create: (_) => ReadingProvider()),
        ChangeNotifierProvider(create: (_) => PaymentProvider()),
        ChangeNotifierProvider(create: (_) => ReportsProvider()),
      ],
      child: const ElectricityCollectorApp(),
    ),
  );
}

class ElectricityCollectorApp extends StatelessWidget {
  const ElectricityCollectorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(360, 690),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'محطة الكهرباء - تطبيق المتحصلين',
          theme: ThemeData(
            primaryColor: const Color(0xFF1A5276),
          ),
          home: const SplashScreen(),
        );
      },
    );
  }
}
