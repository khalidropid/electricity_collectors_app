import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageHelper {
  static const _storage = FlutterSecureStorage();

  // حفظ التوكن (أو بيانات المستخدم)
  static Future<void> saveToken(String token) async {
    await _storage.write(key: 'auth_token', value: token);
  }

  // استرجاع التوكن
  static Future<String?> getToken() async {
    return await _storage.read(key: 'auth_token');
  }

  // حذف التوكن (عند تسجيل الخروج)
  static Future<void> deleteToken() async {
    await _storage.delete(key: 'auth_token');
  }

  // حفظ اسم المتحصل لكي نعرضه في الرئيسية
  static Future<void> saveCollectorName(String name) async {
    await _storage.write(key: 'collector_name', value: name);
  }

  static Future<String?> getCollectorName() async {
    return await _storage.read(key: 'collector_name');
  }

  // دالة لحفظ رقم الموظف (المتحصل)
  static Future<void> saveEmpId(String empId) async {
    await _storage.write(key: 'emp_id', value: empId);
  }

  // دالة لجلب رقم الموظف
  static Future<String?> getEmpId() async {
    return await _storage.read(key: 'emp_id');
  }

  // ==========================================
  // الدوال الجديدة التي تم إضافتها لحل الأخطاء
  // ==========================================

  // دالة لحفظ بيانات المتحصل (الرقم والاسم معاً)
  static Future<void> saveCollectorData(String empId, String empName) async {
    await saveEmpId(empId);
    await saveCollectorName(empName);
  }

  // دالة لحذف جميع البيانات دفعة واحدة (تستخدم عند تسجيل الخروج)
  static Future<void> clearAll() async {
    await _storage.deleteAll();
  }
}