class Payment {
  final int id;
  final String receiptNo; // رقم السند
  final int subscriberId; // المشترك
  final int empId; // الموظف الذي قام بالتحصيل
  final double amount; // المبلغ
  final String? amountChar; // المبلغ كتابة
  final String paymentDate;
  final String paymentMethod;
  final String status;

  Payment({
    required this.id,
    required this.receiptNo,
    required this.subscriberId,
    required this.empId,
    required this.amount,
    this.amountChar,
    required this.paymentDate,
    required this.paymentMethod,
    required this.status,
  });

  // 🌟 1. التصدير لقاعدة البيانات المحلية (SQLite)
  Map<String, dynamic> toMap() {
    return {
      'id': id == 0 ? null : id,
      'receipt_no': receiptNo,
      'subscriber_id': subscriberId,
      'emp_id': empId,
      'amount': amount,
      'amount_char': amountChar,
      'payment_date': paymentDate,
      'payment_method': paymentMethod,
      'status': status,
    };
  }

  Map<String, dynamic> toJson() {
    return toMap();
  }

  // 🌟 2. التصدير الحصري للسيرفر (Supabase - جدول app_collections)
  Map<String, dynamic> toServerMap() {
    return {
      'receipt_no': receiptNo,
      'amount': amount,
      'payment_date': paymentDate,
      'payment_method': paymentMethod,
      'id_customer': subscriberId, // مطابقة لاسم العمود في جدول السيرفر
      'emp_id': empId,
      'status': 'synced',
    };
  }

  // إنشاء الكائن من البيانات (سواء من المحلي أو السيرفر)
  factory Payment.fromMap(Map<String, dynamic> map) {
    return Payment(
      id: map['id'] ?? 0,
      receiptNo: map['receipt_no'] ?? '',
      subscriberId: map['id_customer'] ?? map['subscriber_id'] ?? 0,
      empId: map['emp_id'] ?? 0,
      amount: (map['amount'] ?? 0.0).toDouble(),
      amountChar: map['amount_char'],
      paymentDate: map['payment_date'] ?? '',
      paymentMethod: map['payment_method'] ?? 'نقدي',
      status: map['status'] ?? 'pending',
    );
  }
}