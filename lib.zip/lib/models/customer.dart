class Customer {
  final int id;
  final int? centralId;
  final String subscriberNo;
  final String name;
  final String phone;
  final String? address;
  final int areaId;
  final String status;
  final String? meterNo;
  final double? arrears; 
  final double? lastConsumption; 
  final String? lastMonth; 

  Customer({
    required this.id,
    this.centralId,
    required this.subscriberNo,
    required this.name,
    required this.phone,
    this.address,
    required this.areaId,
    required this.status,
    this.meterNo,
    this.arrears,
    this.lastConsumption,
    this.lastMonth,
  });

  // 🌟 مترجم ذكي: يقرأ من السيرفر (بأسماء قاعدتك) أو من الذاكرة المحلية (بالأسماء العادية)
  factory Customer.fromJson(Map<String, dynamic> json) {
    return Customer(
      id: json['id_customer'] ?? json['id'] ?? 0,
      centralId: json['central_id'],
      subscriberNo: (json['num_account'] ?? json['subscriber_no'] ?? '').toString(),
      name: json['name_customer'] ?? json['name'] ?? 'بدون اسم',
      phone: (json['num_phone'] ?? json['phone'] ?? '').toString(),
      address: json['address_customer'] ?? json['street_customer'] ?? json['address'],
      areaId: json['id_state'] ?? json['area_id'] ?? 1,
      status: json['status'] ?? 'active',
      meterNo: (json['num_addaad'] ?? json['meter_no'])?.toString(),
      arrears: json['arrears'] != null ? (json['arrears'] as num).toDouble() : 0.0,
      lastConsumption: json['last_consumption'] != null ? (json['last_consumption'] as num).toDouble() : 0.0,
      lastMonth: json['last_month'],
    );
  }

  // 🌟 تستخدم فقط لحفظ البيانات داخل الهاتف (SQLite) بأسماء نظيفة ومنظمة
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'central_id': centralId,
      'subscriber_no': subscriberNo,
      'name': name,
      'phone': phone,
      'address': address,
      'area_id': areaId,
      'status': status,
      'meter_no': meterNo,
      'arrears': arrears, 
      'last_consumption': lastConsumption,
      'last_month': lastMonth,
    };
  }
}