//  جدول الفاتورة

class Invoice {
  final int id;
  final String invoiceNo;
  final int subscriberId;
  final double totalAmount;
  final double amountPaid;
  final double remainingAmount;
  final String status;
  final String invoiceDate;

  Invoice({
    required this.id,
    required this.invoiceNo,
    required this.subscriberId,
    required this.totalAmount,
    required this.amountPaid,
    required this.remainingAmount,
    required this.status,
    required this.invoiceDate,
  });

  factory Invoice.fromJson(Map<String, dynamic> json) {
    return Invoice(
      id: json['id'] ?? 0,
      invoiceNo: json['invoice_no'] ?? '',
      subscriberId: json['subscriber_id'] ?? 0,
      totalAmount: double.parse(json['total_amount']?.toString() ?? '0'),
      amountPaid: double.parse(json['amount_paid']?.toString() ?? '0'),
      remainingAmount:
          double.parse(json['remaining_amount']?.toString() ?? '0'),
      status: json['status'] ?? 'unpaid',
      invoiceDate: json['invoice_date'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'invoice_no': invoiceNo,
      'subscriber_id': subscriberId,
      'total_amount': totalAmount,
      'amount_paid': amountPaid,
      'remaining_amount': remainingAmount,
      'status': status,
      'invoice_date': invoiceDate,
    };
  }
}
