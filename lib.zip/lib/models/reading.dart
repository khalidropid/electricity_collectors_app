class Reading {
  final int id;
  final int subscriberId;
  final int meterId;
  final double previousReading;
  final double currentReading;
  final double consumption;
  final String readingDate;
  final String status; // 'pending' أو 'synced'
  final String? imagePath; // مسار الصورة

  Reading({
    required this.id,
    required this.subscriberId,
    required this.meterId,
    required this.previousReading,
    required this.currentReading,
    required this.consumption,
    required this.readingDate,
    required this.status,
    this.imagePath,
  });

  // 🌟 1. التصدير لقاعدة البيانات المحلية (SQLite)
  // يحتفظ بكل البيانات محلياً داخل الهاتف بنفس الأسماء المعتادة
  Map<String, dynamic> toMap() {
    return {
      'id': id == 0 ? null : id,
      'subscriber_id': subscriberId,
      'meter_id': meterId,
      'previous_reading': previousReading,
      'current_reading': currentReading,
      'consumption': consumption,
      'reading_date': readingDate,
      'status': status,
      'image_path': imagePath,
    };
  }

  Map<String, dynamic> toJson() {
    return toMap();
  }

  // 🌟 2. التصدير الحصري للسيرفر (Supabase)
  // يرسل فقط الأعمدة الموجودة في جدول "app_readings" ويستبعد الاستهلاك والقراءة السابقة
  Map<String, dynamic> toServerMap(int empId) {
    return {
      'id_customer': subscriberId,       // مطابقة لجدول السيرفر
      'num_addaad': meterId,             // مطابقة لجدول السيرفر
      'reading_value': currentReading,   // مطابقة لجدول السيرفر
      'reading_date': readingDate,
      'status': 'synced',                // بمجرد الرفع تصبح الحالة متزامنة
      'emp_id': empId,                   // 💡 ربط القراءة برقم الموظف المحصل
      if (imagePath != null) 'image_path': imagePath,
    };
  }

  // بناء الكائن من البيانات (يدعم القراءة من المحلي أو السيرفر)
  factory Reading.fromMap(Map<String, dynamic> map) {
    return Reading(
      id: map['id'] ?? 0,
      subscriberId: map['id_customer'] ?? map['subscriber_id'] ?? 0,
      meterId: map['num_addaad'] ?? map['meter_id'] ?? 1,
      previousReading: (map['previous_reading'] ?? 0.0).toDouble(),
      currentReading: (map['reading_value'] ?? map['current_reading'] ?? 0.0).toDouble(),
      consumption: (map['consumption'] ?? 0.0).toDouble(),
      readingDate: map['reading_date'] ?? '',
      status: map['status'] ?? 'pending',
      imagePath: map['image_path'],
    );
  }
}