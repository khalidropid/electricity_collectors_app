import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  static Database? _database;

  factory DatabaseHelper() => _instance;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    // تحديد مسار قاعدة البيانات في الهاتف
    String path = join(await getDatabasesPath(), 'collectors_app.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  // --- إنشاء الجداول المحلية عند تثبيت التطبيق لأول مرة ---
  Future<void> _onCreate(Database db, int version) async {
    // 1. جدول الموظفين (لعملية تسجيل الدخول أوفلاين)
    await db.execute('''
      CREATE TABLE employees (
        id_emp INTEGER PRIMARY KEY,
        name_emp TEXT,
        username TEXT,
        password TEXT
      )
    ''');

    // 2. جدول المشتركين (متطابق 100% مع قاعدة بياناتك الأساسية mystation)
    await db.execute('''
      CREATE TABLE customer (
        id_customer INTEGER PRIMARY KEY,
        name_customer TEXT NOT NULL,
        num_phone TEXT,
        address_customer TEXT,
        next_customer TEXT,
        Street_customer TEXT,
        type_work TEXT,
        Set_customer TEXT,
        num_account INTEGER,
        num_addaad INTEGER,
        id_state INTEGER,
        TC TEXT
      )
    ''');

    // 3. جدول التحصيلات/السندات (للحفظ المحلي قبل الرفع)
    await db.execute('''
      CREATE TABLE app_collections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        receipt_no TEXT,
        amount REAL,
        payment_date TEXT,
        payment_method TEXT DEFAULT 'نقدي',
        id_customer INTEGER,
        emp_id INTEGER,
        status TEXT DEFAULT 'pending'
      )
    ''');

    // داخل دالة إنشاء الجداول في DatabaseHelper
    // جدول القراءات المحلي
    await db.execute('''
      CREATE TABLE readings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subscriber_id INTEGER,
        meter_id INTEGER,
        previous_reading REAL,
        current_reading REAL,
        consumption REAL,
        reading_date TEXT,
        status TEXT,
        image_path TEXT
      )
    ''');

    // وبقية الجداول الخاصة بك...

    // 5. جدول طلبات التعديل (للحفظ المحلي قبل الرفع)
    await db.execute('''
      CREATE TABLE modification_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        emp_id INTEGER,
        id_customer INTEGER,
        name_customer TEXT,
        address_customer TEXT,
        mod_type TEXT,
        notes TEXT,
        request_date TEXT,
        status TEXT DEFAULT 'pending'
      )
    ''');
    await db.execute('''
  CREATE TABLE collections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    receipt_no TEXT,
    subscriber_id INTEGER,
    emp_id INTEGER,
    amount REAL,
    amount_char TEXT,
    payment_date TEXT,
    payment_method TEXT,
    status TEXT
  )
''');
  }

  // ==========================================================
  // دوال المزامنة والتعامل مع البيانات المحلية (CRUD)
  // ==========================================================

  // 1. مزامنة وحفظ العملاء القادمين من Supabase إلى الهاتف
  Future<void> syncCustomers(List<dynamic> serverCustomers) async {
    final db = await database;
    Batch batch = db.batch();

    // مسح المشتركين القدامى لضمان عدم التكرار وتحديث البيانات بأحدث الأرصدة
    await db.delete('customer');

    for (var cust in serverCustomers) {
      batch.insert(
        'customer',
        {
          'id_customer': cust['id_customer'],
          'name_customer': cust['name_customer'],
          'num_phone':
              cust['num_phone']?.toString(), // تحويل لرقم نصي لتجنب مشاكل الصفر
          'address_customer': cust['address_customer'],
          'next_customer': cust['next_customer'],
          'Street_customer': cust['Street_customer'],
          'type_work': cust['type_work'],
          'Set_customer': cust['Set_customer'],
          'num_account': cust['num_account'],
          'num_addaad': cust['num_addaad'],
          'id_state': cust['id_state'],
          'TC': cust['TC'],
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    await batch.commit(noResult: true);
  }

  // 2. دوال جلب البيانات المعلقة (Pending) لرفعها للسيرفر
  Future<List<Map<String, dynamic>>> getPendingCollections() async {
    final db = await database;
    return await db
        .query('app_collections', where: 'status = ?', whereArgs: ['pending']);
  }

  Future<List<Map<String, dynamic>>> getPendingReadings() async {
    final db = await database;
    return await db
        .query('app_readings', where: 'status = ?', whereArgs: ['pending']);
  }

  Future<List<Map<String, dynamic>>> getPendingModifications() async {
    final db = await database;
    return await db.query('modification_requests',
        where: 'status = ?', whereArgs: ['pending']);
  }

  // 3. دوال تحديث الحالة إلى (synced) بعد نجاح الرفع لـ Supabase
  Future<void> markCollectionsAsSynced(List<int> ids) async {
    final db = await database;
    Batch batch = db.batch();
    for (int id in ids) {
      batch.update('app_collections', {'status': 'synced'},
          where: 'id = ?', whereArgs: [id]);
    }
    await batch.commit(noResult: true);
  }

  Future<void> markReadingsAsSynced(List<int> ids) async {
    final db = await database;
    Batch batch = db.batch();
    for (int id in ids) {
      batch.update('app_readings', {'status': 'synced'},
          where: 'id = ?', whereArgs: [id]);
    }
    await batch.commit(noResult: true);
  }

  Future<void> markModificationsAsSynced(List<int> ids) async {
    final db = await database;
    Batch batch = db.batch();
    for (int id in ids) {
      batch.update('modification_requests', {'status': 'synced'},
          where: 'id = ?', whereArgs: [id]);
    }
    await batch.commit(noResult: true);
  }

  // 4. دالة البحث عن المشتركين محلياً (لشاشة البحث)
  Future<List<Map<String, dynamic>>> searchCustomersLocally(
      String query) async {
    final db = await database;
    return await db.query(
      'customer',
      where: 'name_customer LIKE ? OR num_account LIKE ? OR num_addaad LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
    );
  }
}
