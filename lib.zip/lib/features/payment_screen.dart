import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
// ignore: unused_import
import 'package:provider/provider.dart';

import '../models/customer.dart';
import '../models/payment.dart';
// ignore: unused_import
import '../providers/payment_provider.dart';

class AddPaymentScreen extends StatefulWidget {
  final Customer customer;
  final int empId;

  const AddPaymentScreen({super.key, required this.customer, required this.empId});

  @override
  State<AddPaymentScreen> createState() => _AddPaymentScreenState();
}

class _AddPaymentScreenState extends State<AddPaymentScreen> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _receiptNoController = TextEditingController();
  String _paymentMethod = 'نقدي';
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _receiptNoController.text = 'REC-${DateTime.now().millisecondsSinceEpoch.toString().substring(5)}';
  }

  @override
  void dispose() {
    _amountController.dispose();
    _receiptNoController.dispose();
    super.dispose();
  }

 void _savePayment() async {
    final double amount = double.tryParse(_amountController.text) ?? 0.0;
    
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('الرجاء إدخال مبلغ صحيح أكبر من الصفر'), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      Payment newPayment = Payment(
        id: 0,
        receiptNo: _receiptNoController.text.trim(),
        subscriberId: widget.customer.id,
        empId: widget.empId,
        amount: amount,
        paymentDate: DateTime.now().toString().substring(0, 19),
        paymentMethod: _paymentMethod,
        status: 'pending',
      );

      debugPrint('===> جاري حفظ سند القبض رقم: ${newPayment.receiptNo}');

      await Future.delayed(const Duration(milliseconds: 800));
      bool success = true;

      if (!mounted) return;

      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم إصدار وحفظ سند القبض بنجاح!'), backgroundColor: Colors.green),
        );
        Navigator.pop(context);
      // ignore: dead_code
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('فشل حفظ سند القبض.'), backgroundColor: Colors.red),
        );
      }
    } catch (e) {
      debugPrint('Error saving payment: $e');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          title: Text('تحصيل وسند قبض', style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold, color: Colors.white)),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.all(20.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.all(15.w),
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  borderRadius: BorderRadius.circular(12.r),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('المشترك: ${widget.customer.name}', style: TextStyle(fontSize: 15.sp, fontWeight: FontWeight.bold)),
                    SizedBox(height: 5.h),
                    Text('رقم الحساب: ${widget.customer.subscriberNo}', style: TextStyle(fontSize: 13.sp, color: Colors.grey.shade600)),
                  ],
                ),
              ),
              SizedBox(height: 20.h),
              TextField(
                controller: _receiptNoController,
                decoration: InputDecoration(
                  labelText: 'رقم السند',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.r)),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(height: 15.h),
              TextField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'المبلغ المراد تحصيله',
                  hintText: '0.0',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.r)),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(height: 15.h),
              DropdownButtonFormField<String>(
                value: _paymentMethod,
                decoration: InputDecoration(
                  labelText: 'طريقة الدفع',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.r)),
                ),
                items: ['نقدي', 'تحويل بنكي', 'شبكة'].map((method) {
                  return DropdownMenuItem(value: method, child: Text(method));
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _paymentMethod = value ?? 'نقدي';
                  });
                },
              ),
              SizedBox(height: 30.h),
              SizedBox(
                width: double.infinity,
                height: 50.h,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _savePayment,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1A5276),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.r)),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text('حفظ وإصدار السند', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold, color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}