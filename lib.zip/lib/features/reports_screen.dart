import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart' hide TextDirection;
import '../providers/reports_provider.dart';

// استدعاء ملف القائمة الجانبية
import '../widgets/app_drawer.dart';

// شاشة التقارير اليومية

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  @override
  void initState() {
    super.initState();
    // جلب البيانات فور فتح الشاشة
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<ReportsProvider>(context, listen: false).loadDailyReport();
    });
  }

  @override
  Widget build(BuildContext context) {
    String formattedDate = DateFormat('yyyy-MM-dd').format(DateTime.now());

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),

        // 1. إضافة القائمة الجانبية (Drawer)
        drawer: const AppDrawer(),

        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          title: Text(
            'التقارير اليومية',
            style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),

          // 2. زر القائمة الجانبية في اليمين
          leading: Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: Colors.white),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),

          // 3. زر الرجوع في اليسار
          actions: [
            IconButton(
              icon: const Icon(Icons.arrow_forward_ios, color: Colors.white),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
        body: Consumer<ReportsProvider>(
          builder: (context, provider, child) {
            if (provider.isLoading) {
              return const Center(child: CircularProgressIndicator());
            }

            return SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ترويسة التاريخ
                  Row(
                    children: [
                      Icon(Icons.calendar_month,
                          color: Colors.grey.shade600, size: 24.w),
                      SizedBox(width: 10.w),
                      Text(
                        'إحصائيات اليوم: $formattedDate',
                        style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.h),

                  // 1. بطاقة إجمالي التحصيلات (كبيرة ومميزة)
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(25.w),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [const Color(0xFF1A5276), Colors.blue.shade800],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(15.r),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.blue.withOpacity(0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 5)),
                      ],
                    ),
                    child: Column(
                      children: [
                        Text(
                          'إجمالي النقدية المحصلة',
                          style: TextStyle(
                              fontSize: 16.sp,
                              color: Colors.blue.shade100,
                              fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 10.h),
                        Text(
                          '${provider.totalCollectedToday} ريال',
                          style: TextStyle(
                              fontSize: 32.sp,
                              color: Colors.white,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: 20.h),

                  // 2. بطاقات الإحصائيات الفرعية (عدد السندات وعدد القراءات)
                  Row(
                    children: [
                      Expanded(
                        child: _buildStatCard(
                          title: 'السندات',
                          value: '${provider.paymentsCountToday}',
                          icon: Icons.receipt_long,
                          color: Colors.green,
                        ),
                      ),
                      SizedBox(width: 15.w),
                      Expanded(
                        child: _buildStatCard(
                          title: 'القراءات',
                          value: '${provider.readingsCountToday}',
                          icon: Icons.speed,
                          color: Colors.orange,
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 40.h),

                  // زر تحديث البيانات
                  Center(
                    child: TextButton.icon(
                      onPressed: () {
                        provider.loadDailyReport();
                      },
                      icon: const Icon(Icons.refresh),
                      label: const Text('تحديث البيانات'),
                      style: TextButton.styleFrom(
                        foregroundColor: const Color(0xFF1A5276),
                        textStyle: TextStyle(
                            fontSize: 16.sp, fontWeight: FontWeight.bold),
                      ),
                    ),
                  )
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // دالة مساعدة لبناء البطاقات المربعة
  Widget _buildStatCard(
      {required String title,
      required String value,
      required IconData icon,
      required Color color}) {
    return Container(
      padding: EdgeInsets.all(20.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15.r),
        boxShadow: [
          BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 5)),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(12.w),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 30.w),
          ),
          SizedBox(height: 15.h),
          Text(
            value,
            style: TextStyle(
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black87),
          ),
          SizedBox(height: 5.h),
          Text(
            title,
            style: TextStyle(
                fontSize: 14.sp,
                color: Colors.grey.shade600,
                fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
