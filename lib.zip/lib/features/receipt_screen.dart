// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'dashboard_screen.dart'; // سنحتاجه للعودة للرئيسية

// // شاشة ايصال التحصيل

// class ReceiptScreen extends StatelessWidget {
//   const ReceiptScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Directionality(
//       textDirection: TextDirection.rtl,
//       child: Scaffold(
//         backgroundColor: Colors.white,
//         appBar: AppBar(
//           backgroundColor: const Color(0xFF1A5276),
//           title: Text(
//             'إيصال التحصيل',
//             style: TextStyle(
//                 fontSize: 18.sp,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.white),
//           ),
//           centerTitle: true,
//           iconTheme: const IconThemeData(color: Colors.white),
//           actions: [
//             IconButton(
//               icon: const Icon(Icons.search_outlined),
//               onPressed: () {},
//             ),
//           ],
//         ),
//         body: SingleChildScrollView(
//           padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 30.h),
//           child: Column(
//             children: [
//               // 1. علامة الصح الخضراء للنجاح
//               Container(
//                 padding: EdgeInsets.all(15.w),
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   border: Border.all(color: Colors.green, width: 3),
//                 ),
//                 child: Icon(
//                   Icons.check,
//                   color: Colors.green,
//                   size: 50.w,
//                 ),
//               ),
//               SizedBox(height: 15.h),

//               Text(
//                 'تم تسجيل التحصيل بنجاح',
//                 style: TextStyle(
//                     fontSize: 16.sp,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.black87),
//               ),
//               SizedBox(height: 10.h),

//               // رقم الإيصال
//               Text(
//                 'RC-2024-000125',
//                 style: TextStyle(
//                     fontSize: 22.sp,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.black),
//               ),
//               SizedBox(height: 30.h),

//               // 2. بطاقة تفاصيل الإيصال
//               Container(
//                 padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 20.h),
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   border: Border.all(color: Colors.grey.shade300),
//                   borderRadius: BorderRadius.circular(10.r),
//                 ),
//                 child: Column(
//                   children: [
//                     _buildReceiptRow('المشترك', 'عبدالله أحمد علي'),
//                     _buildReceiptRow('المبلغ', '40,000'),
//                     _buildReceiptRow('التاريخ', '2024-05-25  10:30'),
//                     _buildReceiptRow('طريقة الدفع', 'نقدي'),
//                     _buildReceiptRow('المتحصل', 'أحمد محمد'),
//                     _buildReceiptRow('المنطقة', 'منطقة الحبيان', isLast: true),
//                   ],
//                 ),
//               ),
//               SizedBox(height: 40.h),

//               // 3. أزرار الإجراءات
//               // زر إرسال SMS
//               SizedBox(
//                 width: double.infinity,
//                 child: ElevatedButton(
//                   onPressed: () {
//                     // كود إرسال الرسالة النصية
//                   },
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.green,
//                     padding: EdgeInsets.symmetric(vertical: 12.h),
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(8.r)),
//                   ),
//                   child: Text(
//                     'إرسال رسالة SMS',
//                     style: TextStyle(
//                         fontSize: 15.sp,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.white),
//                   ),
//                 ),
//               ),
//               SizedBox(height: 15.h),

//               // زر طباعة الإيصال
//               SizedBox(
//                 width: double.infinity,
//                 child: ElevatedButton(
//                   onPressed: () {
//                     // كود الطباعة
//                   },
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor:
//                         const Color(0xFF1A5276), // اللون الأزرق الداكن
//                     padding: EdgeInsets.symmetric(vertical: 12.h),
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(8.r)),
//                   ),
//                   child: Text(
//                     'طباعة الإيصال',
//                     style: TextStyle(
//                         fontSize: 15.sp,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.white),
//                   ),
//                 ),
//               ),
//               SizedBox(height: 15.h),

//               // زر العودة للرئيسية (نصي فقط بدون خلفية كما في التصميم)
//               TextButton(
//                 onPressed: () {
//                   // العودة للصفحة الرئيسية وإغلاق جميع الشاشات السابقة
//                   Navigator.pushAndRemoveUntil(
//                     context,
//                     MaterialPageRoute(
//                         builder: (context) => const DashboardScreen()),
//                     (Route<dynamic> route) => false,
//                   );
//                 },
//                 child: Text(
//                   'العودة للرئيسية',
//                   style: TextStyle(
//                       fontSize: 16.sp,
//                       fontWeight: FontWeight.bold,
//                       color: const Color(0xFF1A5276)),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   // دالة مساعدة لإنشاء صفوف الإيصال
//   Widget _buildReceiptRow(String label, String value, {bool isLast = false}) {
//     return Padding(
//       padding: EdgeInsets.only(bottom: isLast ? 0 : 15.h),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(
//             label,
//             style: TextStyle(
//                 fontSize: 14.sp,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.black87),
//           ),
//           Text(
//             value,
//             style: TextStyle(fontSize: 14.sp, color: Colors.grey.shade700),
//           ),
//         ],
//       ),
//     );
//   }
// }
