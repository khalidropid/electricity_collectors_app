import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../providers/customer_provider.dart';
import 'customer_details_screen.dart';
import '../widgets/app_drawer.dart';

class CustomerSearchScreen extends StatefulWidget {
  final int? empId; // استقبال المعرف إن وجد
  const CustomerSearchScreen({super.key, this.empId});

  @override
  State<CustomerSearchScreen> createState() => _CustomerSearchScreenState();
}

class _CustomerSearchScreenState extends State<CustomerSearchScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = Provider.of<CustomerProvider>(context, listen: false);
      
      // إذا كان المتحصل معروفاً يتم جلب عملائه فقط، وإلا يجلب الكل
      if (widget.empId != null) {
        provider.loadCustomersForCollector(widget.empId!);
      } else {
        provider.loadCustomers();
      }
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),
        drawer: const AppDrawer(),
        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          title: Text('بحث المشتركين', style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold, color: Colors.white)),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
          leading: Builder(
            builder: (context) => IconButton(icon: const Icon(Icons.menu, color: Colors.white), onPressed: () => Scaffold.of(context).openDrawer()),
          ),
          actions: [
            IconButton(icon: const Icon(Icons.arrow_forward_ios, color: Colors.white), onPressed: () => Navigator.pop(context)),
          ],
        ),
        body: Column(
          children: [
            Container(
              color: const Color(0xFF1A5276),
              padding: EdgeInsets.only(left: 20.w, right: 20.w, bottom: 20.h),
              child: TextField(
                controller: _searchController,
                onChanged: (value) => Provider.of<CustomerProvider>(context, listen: false).search(value),
                decoration: InputDecoration(
                  hintText: 'الاسم، رقم المشترك، الهاتف، العداد',
                  filled: true,
                  fillColor: Colors.white,
                  prefixIcon: const Icon(Icons.search, color: Colors.grey),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.clear, color: Colors.grey),
                    onPressed: () {
                      _searchController.clear();
                      Provider.of<CustomerProvider>(context, listen: false).search('');
                    },
                  ),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.r), borderSide: BorderSide.none),
                ),
              ),
            ),
            Expanded(
              child: Consumer<CustomerProvider>(
                builder: (context, provider, child) {
                  if (provider.isLoading) return const Center(child: CircularProgressIndicator());
                  if (provider.searchResults.isEmpty) {
                    return Center(child: Text('لا يوجد مشتركون بهذا الاسم أو الرقم', style: TextStyle(fontSize: 16.sp)));
                  }
                  return ListView.builder(
                    padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 15.h),
                    itemCount: provider.searchResults.length,   // مصححة (حرف C كبير)
                    itemBuilder: (context, index) {             // مصححة (حرف B كبير)
                      final customer = provider.searchResults[index];
                      return _buildCustomerCard(customer);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomerCard(customer) {
    return InkWell(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => CustomerDetailsScreen(customer: customer)));
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 15.h),
        padding: EdgeInsets.all(15.w),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: Colors.grey.shade200),
          boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.05), blurRadius: 5, offset: const Offset(0, 3))],
        ),
        child: Row(
          children: [
            CircleAvatar(radius: 25.r, backgroundColor: Colors.blue.shade50, child: Icon(Icons.person, color: const Color(0xFF1A5276), size: 28.w)),
            SizedBox(width: 15.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(customer.name, style: TextStyle(fontSize: 15.sp, fontWeight: FontWeight.bold, color: Colors.black87)),
                  SizedBox(height: 5.h),
                  Row(
                    children: [
                      Icon(Icons.confirmation_number_outlined, size: 14.w, color: Colors.grey.shade600),
                      SizedBox(width: 5.w),
                      Text(customer.subscriberNo, style: TextStyle(fontSize: 13.sp, color: Colors.grey.shade600)),
                    ],
                  ),
                  SizedBox(height: 5.h),
                  Row(
                    children: [
                      Icon(Icons.speed, size: 14.w, color: Colors.grey.shade600),
                      SizedBox(width: 5.w),
                      Text('العداد: ${customer.meterNo ?? "غير متوفر"}', style: TextStyle(fontSize: 13.sp, color: Colors.grey.shade600)),
                    ],
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, size: 16.w, color: Colors.grey.shade400),
          ],
        ),
      ),
    );
  }
}