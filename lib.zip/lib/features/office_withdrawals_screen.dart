import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

//شاشة التسدسدات المكتبية

class OfficeWithdrawalsScreen extends StatelessWidget {
  const OfficeWithdrawalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // بيانات وهمية مطابقة للصورة تماماً
    final List<Map<String, dynamic>> _payments = [
      {
        'receipt': 'OFF-2024-00045',
        'name': 'عبدالله أحمد علي',
        'amount': '15,000',
        'date': '2024-05-10'
      },
      {
        'receipt': 'OFF-2024-00044',
        'name': 'محمد علي محمد',
        'amount': '20,000',
        'date': '2024-05-09'
      },
      {
        'receipt': 'OFF-2024-00043',
        'name': 'أحمد حسن ثابت',
        'amount': '10,000',
        'date': '2024-05-08'
      },
      {
        'receipt': 'OFF-2024-00042',
        'name': 'صالح محمد علي',
        'amount': '25,000',
        'date': '2024-05-07'
      },
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA), // لون الخلفية الموحد
        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          title: Text(
            'التسديدات المكتبية',
            style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
          actions: [
            IconButton(
              icon: const Icon(Icons.search_outlined),
              onPressed: () {},
            ),
          ],
        ),
        body: ListView.builder(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
          itemCount: _payments.length,
          itemBuilder: (context, index) {
            final payment = _payments[index];
            return _buildPaymentCard(payment);
          },
        ),
      ),
    );
  }

  // تصميم بطاقة التسديد المكتبي
  Widget _buildPaymentCard(Map<String, dynamic> payment) {
    return Container(
      margin: EdgeInsets.only(bottom: 15.h),
      padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.r),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.05),
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // 1. رقم الإيصال والاسم (الجانب الأيمن)
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  payment['name']!,
                  style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87),
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 5.h),
                Text(
                  payment['receipt']!,
                  style:
                      TextStyle(fontSize: 12.sp, color: Colors.grey.shade600),
                ),
              ],
            ),
          ),

          // 2. المبلغ والتاريخ (الجانب الأوسط)
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  payment['amount']!,
                  style: TextStyle(
                      fontSize: 15.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87),
                ),
                SizedBox(height: 5.h),
                Text(
                  payment['date']!,
                  style:
                      TextStyle(fontSize: 12.sp, color: Colors.grey.shade600),
                ),
              ],
            ),
          ),
          SizedBox(width: 15.w),

          // 3. الأيقونة البنفسجية (الجانب الأيسر)
          Container(
            padding: EdgeInsets.all(10.w),
            decoration: BoxDecoration(
              color: Colors.purple.shade50,
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Icon(Icons.receipt_long,
                color: Colors.purple.shade400, size: 24.w),
          ),
        ],
      ),
    );
  }
}
