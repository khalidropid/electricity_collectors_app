import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart'; // استدعاء مزود الحالة

// استدعاء ملف القائمة الجانبية والشاشات والمزودات
import '../widgets/app_drawer.dart';
import 'change_password_screen.dart';
import 'login_screen.dart';
import '../providers/auth_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  // --- دالة عرض نافذة تأكيد الخروج ---
  void _showLogoutConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.r)),
            title: Row(
              children: [
                const Icon(Icons.warning_amber_rounded,
                    color: Colors.red, size: 28),
                SizedBox(width: 10.w),
                Text('تأكيد الخروج',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 18.sp)),
              ],
            ),
            content: Text('هل أنت متأكد أنك تريد تسجيل الخروج من الحساب؟',
                style: TextStyle(fontSize: 15.sp)),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(dialogContext).pop(); // إغلاق النافذة
                },
                child: Text('إلغاء',
                    style: TextStyle(
                        color: Colors.grey.shade700,
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(dialogContext).pop(); // إغلاق النافذة
                  _logout(context); // تنفيذ الخروج الفعلي
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.r)),
                ),
                child: Text('تسجيل الخروج',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 14.sp,
                        fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        );
      },
    );
  }

  // --- دالة تسجيل الخروج الفعلية ---
  void _logout(BuildContext context) async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    await authProvider.logout(); // مسح الجلسة والتوكن

    if (context.mounted) {
      // إغلاق جميع الشاشات والعودة لشاشة تسجيل الدخول
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),

        // 1. إضافة القائمة الجانبية (Drawer)
        drawer: const AppDrawer(),

        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          title: Text(
            'الإعدادات',
            style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),

          // 2. زر القائمة الجانبية في اليمين
          leading: Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: Colors.white),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),

          // 3. زر الرجوع في اليسار
          actions: [
            IconButton(
              icon: const Icon(Icons.arrow_forward_ios, color: Colors.white),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
        body: ListView(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
          children: [
            _buildSettingsItem(
              title: 'إعدادات طابعة البلوتوث',
              icon: Icons.print,
              onTap: () {
                // سيتم ربطها لاحقاً بمكتبة الطباعة
              },
            ),
            _buildSettingsItem(
              title: 'إعدادات السيرفر',
              icon: Icons.dns,
              onTap: () {
                // نافذة لتعديل رابط الـ API أو IP السيرفر
              },
            ),
            _buildSettingsItem(
              title: 'تغيير كلمة المرور',
              icon: Icons.lock_outline,
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ChangePasswordScreen()));
              },
            ),
            SizedBox(height: 30.h),

            // زر تسجيل الخروج مع نافذة التأكيد
            _buildSettingsItem(
              title: 'تسجيل الخروج',
              icon: Icons.logout,
              color: Colors.red,
              onTap: () {
                _showLogoutConfirmation(context); // استدعاء نافذة التأكيد
              },
            ),
          ],
        ),
      ),
    );
  }

  // دالة مساعدة لبناء عناصر الإعدادات
  Widget _buildSettingsItem(
      {required String title,
      required IconData icon,
      required VoidCallback onTap,
      Color? color}) {
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        boxShadow: [
          BoxShadow(
              color: Colors.grey.withOpacity(0.05),
              blurRadius: 5,
              offset: const Offset(0, 2)),
        ],
      ),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          padding: EdgeInsets.all(8.w),
          decoration: BoxDecoration(
            color: (color ?? const Color(0xFF1A5276)).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8.r),
          ),
          child: Icon(icon, color: color ?? const Color(0xFF1A5276)),
        ),
        title: Text(
          title,
          style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.bold,
              color: color ?? Colors.black87),
        ),
        trailing: Icon(Icons.arrow_forward_ios,
            size: 16.w, color: Colors.grey.shade400),
      ),
    );
  }
}
