import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../database/database_helper.dart';
import '../models/reading.dart';
import '../models/payment.dart';

class SyncScreen extends StatefulWidget {
  final int empId;

  const SyncScreen({super.key, required this.empId});

  @override
  State<SyncScreen> createState() => _SyncScreenState();
}

class _SyncScreenState extends State<SyncScreen> {
  bool _isSyncing = false;
  
  // عدادات البيانات المعلقة
  int _pendingReadingsCount = 0;
  int _pendingPaymentsCount = 0;
  int _pendingModRequestsCount = 0;

  // قوائم البيانات المعلقة
  List<Map<String, dynamic>> _pendingReadingsList = [];
  List<Map<String, dynamic>> _pendingPaymentsList = [];
  List<Map<String, dynamic>> _pendingModRequestsList = [];

  @override
  void initState() {
    super.initState();
    _loadPendingData();
  }

  // 1. جلب البيانات المعلقة من قاعدة البيانات المحلية
  Future<void> _loadPendingData() async {
    final db = await DatabaseHelper().database;

    final readings = await db.query('readings', where: 'status = ?', whereArgs: ['pending']);
    final payments = await db.query('collections', where: 'status = ?', whereArgs: ['pending']);
    final modRequests = await db.query('modification_requests', where: 'status = ?', whereArgs: ['pending']);

    if (mounted) {
      setState(() {
        _pendingReadingsList = readings;
        _pendingPaymentsList = payments;
        _pendingModRequestsList = modRequests; 

        _pendingReadingsCount = readings.length;
        _pendingPaymentsCount = payments.length;
        _pendingModRequestsCount = modRequests.length; 
      });
    }
  }

  // 2. دالة المزامنة الشاملة
  Future<void> _startSync() async {
    if (_pendingReadingsCount == 0 && _pendingPaymentsCount == 0 && _pendingModRequestsCount == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لا توجد بيانات معلقة للمزامنة!'), backgroundColor: Colors.blue),
      );
      return;
    }

    setState(() => _isSyncing = true);
    final supabase = Supabase.instance.client;
    final db = await DatabaseHelper().database;
    
    int syncedReadings = 0;
    int syncedPayments = 0;
    int syncedModRequests = 0;

    try {
      // ---- 1. مزامنة القراءات ----
      for (var map in _pendingReadingsList) {
        try {
          Reading reading = Reading.fromMap(map);
          await supabase.from('app_readings').insert(reading.toServerMap(widget.empId));
          await db.update('readings', {'status': 'synced'}, where: 'id = ?', whereArgs: [reading.id]);
          syncedReadings++;
        } catch (e) {
          debugPrint('خطأ في مزامنة القراءة رقم ${map['id']}: $e');
        }
      }

      // ---- 2. مزامنة التحصيلات والسندات ----
      for (var map in _pendingPaymentsList) {
        try {
          Payment payment = Payment.fromMap(map);
          await supabase.from('app_collections').insert(payment.toServerMap());
          await db.update('collections', {'status': 'synced'}, where: 'id = ?', whereArgs: [payment.id]);
          syncedPayments++;
        } catch (e) {
          debugPrint('خطأ في مزامنة التحصيل رقم ${map['id']}: $e');
        }
      }

      // ---- 3. 🌟 مزامنة طلبات التعديل ----
      for (var map in _pendingModRequestsList) {
        try {
          // أخذ نسخة من البيانات وتجهيزها للسيرفر (إزالة id المحلي و status)
          Map<String, dynamic> serverData = Map<String, dynamic>.from(map);
          int localId = serverData.remove('id');
          serverData.remove('status');

          // 🌟 تم التعديل هنا: اسم الجدول modification_requests
          await supabase.from('modification_requests').insert(serverData);
          
          // تحديث الحالة محلياً إلى متزامن
          await db.update('modification_requests', {'status': 'synced'}, where: 'id = ?', whereArgs: [localId]);
          syncedModRequests++;
        } catch (e) {
          debugPrint('خطأ في مزامنة طلب التعديل رقم ${map['id']}: $e');
        }
      }

      // إعادة تحميل الإحصائيات بعد انتهاء المزامنة
      await _loadPendingData();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('تمت المزامنة: $syncedReadings قراءة، $syncedPayments تحصيل، $syncedModRequests طلب تعديل.'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ أثناء الاتصال بالسيرفر. تأكد من الإنترنت.'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isSyncing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),
        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          title: Text(
            'مزامنة البيانات',
            style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: Padding(
          padding: EdgeInsets.all(20.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'البيانات المعلقة التي لم تُرفع للسيرفر',
                style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold, color: Colors.black87),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 30.h),

              // بطاقة القراءات
              _buildSyncCard(
                title: 'قراءات العدادات',
                count: _pendingReadingsCount,
                icon: Icons.speed,
                color: Colors.orange,
              ),
              SizedBox(height: 15.h),

              // بطاقة التحصيلات
              _buildSyncCard(
                title: 'سندات القبض (التحصيل)',
                count: _pendingPaymentsCount,
                icon: Icons.monetization_on_outlined,
                color: Colors.green,
              ),
              SizedBox(height: 15.h),

              // بطاقة طلبات التعديل
              _buildSyncCard(
                title: 'طلبات التعديل',
                count: _pendingModRequestsCount,
                icon: Icons.edit_document,
                color: Colors.blue,
              ),
              
              const Spacer(),

              // زر المزامنة
              SizedBox(
                height: 55.h,
                child: ElevatedButton(
                  onPressed: _isSyncing ? null : _startSync,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1A5276),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
                  ),
                  child: _isSyncing
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(
                              height: 24,
                              width: 24,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                            ),
                            SizedBox(width: 15.w),
                            Text('جاري الرفع للسيرفر...', style: TextStyle(fontSize: 16.sp, color: Colors.white)),
                          ],
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.cloud_upload, color: Colors.white),
                            SizedBox(width: 10.w),
                            Text('بدء المزامنة الآن', style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold, color: Colors.white)),
                          ],
                        ),
                ),
              ),
              SizedBox(height: 20.h),
            ],
          ),
        ),
      ),
    );
  }

  // تصميم بطاقات الإحصائيات
  Widget _buildSyncCard({required String title, required int count, required IconData icon, required Color color}) {
    return Container(
      padding: EdgeInsets.all(15.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(color: Colors.grey.withOpacity(0.1), blurRadius: 5, offset: const Offset(0, 3)),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(12.w),
            decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 28.w),
          ),
          SizedBox(width: 15.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontSize: 15.sp, fontWeight: FontWeight.bold)),
                SizedBox(height: 5.h),
                Text(
                  count > 0 ? 'يوجد $count بحاجة للرفع' : 'متزامن بالكامل',
                  style: TextStyle(fontSize: 13.sp, color: count > 0 ? Colors.red.shade600 : Colors.green.shade600, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          if (count > 0) Icon(Icons.warning_amber_rounded, color: Colors.red.shade400),
          if (count == 0) Icon(Icons.check_circle, color: Colors.green.shade400),
        ],
      ),
    );
  }
}