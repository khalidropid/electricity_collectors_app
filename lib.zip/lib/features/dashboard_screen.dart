import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import 'customer_search_screen.dart';
import 'reports_screen.dart';
import 'sync_screen.dart';
import 'settings_screen.dart';
import 'login_screen.dart';
import '../providers/auth_provider.dart';
import '../core/utils/secure_storage_helper.dart';
import '../widgets/app_drawer.dart';

class DashboardScreen extends StatefulWidget {
  final int? empId; 
  const DashboardScreen({super.key, this.empId});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String _collectorName = 'جاري التحميل...';
  int? _currentEmpId; 

  @override
  void initState() {
    super.initState();
    _currentEmpId = widget.empId; 
    _loadData();
  }

  Future<void> _loadData() async {
    String? name = await SecureStorageHelper.getCollectorName();
    
    if (_currentEmpId == null) {
      String? savedEmpId = await SecureStorageHelper.getEmpId();
      if (savedEmpId != null) {
        _currentEmpId = int.tryParse(savedEmpId);
      }
    }

    if (mounted) {
      setState(() {
        _collectorName = name ?? 'متحصل مجهول';
      });
    }
  }

  // ==========================================
  // 🌟 1. الدالة الذكية لفحص البيانات قبل الخروج
  // ==========================================
  Future<void> _handleLogoutPressed() async {
    // 💡 قم باستبدال هذا السطر بدالة فحص SQLite الخاصة بك.
    // مثال: int pendingCount = await DatabaseHelper.instance.getPendingRecordsCount();
    
    int pendingCount = 0; // نفترض حالياً أنها 0 للتجربة، اربطها بجدول SQLite الخاص بك.

    if (pendingCount > 0) {
      // توجد بيانات لم ترفع، إظهار تحذير المزامنة
      _showPendingDataWarning(pendingCount);
    } else {
      // لا توجد بيانات معلقة، إظهار تأكيد الخروج العادي
      _showLogoutConfirmation();
    }
  }

  // ==========================================
  // 🌟 2. نافذة تحذير المزامنة (تمنع الخروج)
  // ==========================================
  void _showPendingDataWarning(int count) {
    showDialog(
      context: context,
      barrierDismissible: false, // لمنع إغلاق النافذة باللمس خارجها
      builder: (BuildContext context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.r)),
            title: Row(
              children: [
                const Icon(Icons.sync_problem, color: Colors.orange, size: 28),
                SizedBox(width: 10.w),
                Text('تنبيه هام!', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.sp, color: Colors.orange)),
              ],
            ),
            content: Text(
              'يوجد لديك ($count) عمليات لم يتم مزامنتها مع السيرفر.\nيرجى مزامنتها أولاً قبل تسجيل الخروج لضمان عدم ضياع بيانات المشتركين.', 
              style: TextStyle(fontSize: 15.sp, height: 1.5)
            ),
            actions: [
              TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('إلغاء')),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  // 🌟 تم الإصلاح هنا بتمرير empId
                  Navigator.push(
                    context, 
                    MaterialPageRoute(builder: (context) => SyncScreen(empId: _currentEmpId ?? 1))
                  );
                },
                style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                child: const Text('الذهاب للمزامنة', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
        );
      },
    );
  }

  // ==========================================
  // 3. نافذة تأكيد الخروج الطبيعية
  // ==========================================
  void _showLogoutConfirmation() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.r)),
            title: Row(
              children: [
                const Icon(Icons.warning_amber_rounded, color: Colors.red, size: 28),
                SizedBox(width: 10.w),
                Text('تأكيد الخروج', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.sp)),
              ],
            ),
            content: Text('هل أنت متأكد أنك تريد تسجيل الخروج؟', style: TextStyle(fontSize: 15.sp)),
            actions: [
              TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('إلغاء')),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _logout();
                },
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                child: const Text('خروج', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
        );
      },
    );
  }

  void _logout() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    await authProvider.logout();
    
    await SecureStorageHelper.clearAll();

    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),
        drawer: const AppDrawer(),
        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          elevation: 0,
          title: Text('الرئيسية', style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold, color: Colors.white)),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
          actions: [
            IconButton(icon: const Icon(Icons.logout), onPressed: _handleLogoutPressed)
          ],
        ),
        body: Column(
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 20.h),
              decoration: const BoxDecoration(
                  color: Color(0xFF1A5276),
                  borderRadius: BorderRadius.only(bottomLeft: Radius.circular(20), bottomRight: Radius.circular(20))),
              child: Row(
                children: [
                  CircleAvatar(radius: 30.r, backgroundColor: Colors.white.withOpacity(0.2), child: Icon(Icons.person, size: 35.w, color: Colors.white)),
                  SizedBox(width: 15.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_collectorName, style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold, color: Colors.white)),
                      SizedBox(height: 5.h),
                      Row(
                        children: [
                          Container(width: 10.w, height: 10.w, decoration: const BoxDecoration(color: Colors.greenAccent, shape: BoxShape.circle)),
                          SizedBox(width: 5.w),
                          Text('متصل', style: TextStyle(fontSize: 14.sp, color: Colors.white70)),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 20.h),
            Expanded(
              child: GridView.count(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                crossAxisCount: 3,
                crossAxisSpacing: 15.w,
                mainAxisSpacing: 15.h,
                childAspectRatio: 0.75,
                children: [
                  _buildMenuItem('القراءات', Icons.speed, Colors.green, context),
                  _buildMenuItem('التحصيل', Icons.monetization_on_outlined, Colors.deepOrange, context),
                  _buildMenuItem('بحث المشتركين', Icons.search, Colors.blue, context),
                  _buildMenuItem('التقارير', Icons.bar_chart, Colors.indigo, context),
                  _buildMenuItem('المزامنة', Icons.sync, Colors.teal, context),
                  _buildMenuItem('الإعدادات', Icons.settings, Colors.blueGrey, context),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItem(String title, IconData icon, Color color, BuildContext context) {
    return InkWell(
      onTap: () {
        if (title == 'بحث المشتركين' || title == 'القراءات' || title == 'التحصيل') {
          // نفترض أن CustomerSearchScreen تم تعديلها لتقبل nullable أو أننا نمرر قيمة افتراضية
          Navigator.push(context, MaterialPageRoute(builder: (context) => CustomerSearchScreen(empId: _currentEmpId ?? 1)));
        } else if (title == 'التقارير') {
          Navigator.push(context, MaterialPageRoute(builder: (context) => const ReportsScreen()));
        } else if (title == 'المزامنة') {
          // 🌟 تم الإصلاح هنا أيضاً بتمرير empId
          Navigator.push(context, MaterialPageRoute(builder: (context) => SyncScreen(empId: _currentEmpId ?? 1)));
        } else if (title == 'الإعدادات') {
          Navigator.push(context, MaterialPageRoute(builder: (context) => const SettingsScreen()));
        }
      },
      borderRadius: BorderRadius.circular(15.r),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 5.w),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15.r),
          boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.15), spreadRadius: 1, blurRadius: 5, offset: const Offset(0, 3))],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(12.w),
              decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12.r)),
              child: Icon(icon, color: color, size: 28.w),
            ),
            SizedBox(height: 8.h),
            Expanded(
              child: Text(title, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.bold, color: Colors.black87)),
            ),
          ],
        ),
      ),
    );
  }
}