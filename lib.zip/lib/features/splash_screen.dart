import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import 'login_screen.dart';
import 'dashboard_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkLoginAndNavigate();
  }

  Future<void> _checkLoginAndNavigate() async {
    // تشغيل التأخير الزمني المطلوب للشعار + الفحص الآمن بالتوازي لسرعة الأداء
    final results = await Future.wait([
      Future.delayed(const Duration(seconds: 2)), // وقت عرض الشعار
      _safeCheckLogin(), // الفحص الآمن لمنع أي تعليق
    ]);

    if (!mounted) return;

    bool isLoggedIn = results[1] as bool;

    // التوجيه الذكي بناءً على حالة الحفظ المحلي
    if (isLoggedIn) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const DashboardScreen()),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
      );
    }
  }

  // دالة فحص آمنة مع مهلة زمنية قصيرة (Timeout) لمنع تجميد التطبيق نهائياً
  Future<bool> _safeCheckLogin() async {
    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      return await authProvider.checkLoginStatus().timeout(
            const Duration(seconds: 3),
            onTimeout: () =>
                false, // إذا حدث بطء في النظام، يتم التحويل لصفحة الدخول فوراً
          );
    } catch (e) {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A5276), // لون التطبيق الأساسي
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/SLOGAN_STATION_ALHASN9.png',
              width: 150.w,
              height: 150.w,
              fit: BoxFit.contain,
            ),
            SizedBox(height: 20.h),
            Text(
              'تطبيق المتحصلين',
              style: TextStyle(
                fontSize: 28.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 40.h),
            const CircularProgressIndicator(color: Colors.white),
          ],
        ),
      ),
    );
  }
}
