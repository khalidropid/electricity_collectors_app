import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/customer.dart';

import 'add_reading_screen.dart';
import 'payment_screen.dart';
import '../widgets/app_drawer.dart';

// شاشة تفاصيل المشتركين
class CustomerDetailsScreen extends StatelessWidget {
  final Customer customer;
  final int empId;

  const CustomerDetailsScreen({
    super.key, 
    required this.customer, 
    this.empId = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),
        drawer: const AppDrawer(),
        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          title: Text(
            'تفاصيل المشترك',
            style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
          leading: Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: Colors.white),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.arrow_forward_ios, color: Colors.white),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(20.w),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15.r),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.grey.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, 5)),
                  ],
                ),
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 35.r,
                      backgroundColor: const Color(0xFF1A5276).withOpacity(0.1),
                      child: Icon(Icons.person,
                          size: 40.w, color: const Color(0xFF1A5276)),
                    ),
                    SizedBox(height: 15.h),
                    Text(
                      customer.name,
                      style: TextStyle(
                          fontSize: 20.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87),
                    ),
                    SizedBox(height: 5.h),
                    Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 12.w, vertical: 5.h),
                      decoration: BoxDecoration(
                        color: customer.status == 'active'
                            ? Colors.green.shade50
                            : Colors.red.shade50,
                        borderRadius: BorderRadius.circular(20.r),
                      ),
                      child: Text(
                        customer.status == 'active' ? 'نشط' : 'مفصول',
                        style: TextStyle(
                          fontSize: 12.sp,
                          color: customer.status == 'active'
                              ? Colors.green.shade700
                              : Colors.red.shade700,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Divider(height: 30.h, color: Colors.grey.shade200),
                    _buildDetailRow(Icons.confirmation_number_outlined,
                        'رقم المشترك', customer.subscriberNo),
                    _buildDetailRow(Icons.speed, 'رقم العداد',
                        customer.meterNo ?? 'غير متوفر'),
                    _buildDetailRow(
                        Icons.phone_outlined, 'رقم الهاتف', customer.phone),
                    _buildDetailRow(Icons.location_on_outlined, 'العنوان',
                        customer.address ?? 'غير متوفر'),
                    _buildDetailRow(Icons.money_off_outlined, 'المتأخرات',
                        '${customer.arrears ?? 0.0} ريال',
                        valueColor: Colors.red.shade700),
                    _buildDetailRow(Icons.electric_bolt_outlined, 'الاستهلاك',
                        '${customer.lastConsumption ?? 0.0} ك.و.س',
                        valueColor: Colors.orange.shade700),
                    _buildDetailRow(Icons.calendar_month_outlined, 'الشهر',
                        customer.lastMonth ?? 'غير متوفر'),
                  ],
                ),
              ),
              SizedBox(height: 30.h),
              Row(
                children: [
                  Expanded(
                    child: _buildActionButton(
                      context,
                      title: 'تسجيل قراءة',
                      icon: Icons.speed,
                      color: Colors.orange,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    AddReadingScreen(customer: customer)));
                      },
                    ),
                  ),
                  SizedBox(width: 15.w),
                  Expanded(
                    child: _buildActionButton(
                      context,
                      title: 'تحصيل فاتورة',
                      icon: Icons.monetization_on_outlined,
                      color: Colors.green,
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => AddPaymentScreen(
                                      customer: customer,
                                      empId: empId,
                                    )));
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value,
      {Color? valueColor}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12.h),
      child: Row(
        children: [
          Icon(icon, size: 20.w, color: Colors.grey.shade500),
          SizedBox(width: 10.w),
          Text(label,
              style: TextStyle(fontSize: 13.sp, color: Colors.grey.shade600)),
          const Spacer(),
          Text(value,
              style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.bold,
                  color: valueColor ?? Colors.black87)),
        ],
      ),
    );
  }

  Widget _buildActionButton(BuildContext context,
      {required String title,
      required IconData icon,
      required Color color,
      required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12.r),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 15.h),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 28.w),
            SizedBox(height: 8.h),
            Text(title,
                style: TextStyle(
                    fontSize: 13.sp,
                    fontWeight: FontWeight.bold,
                    color: color)),
          ],
        ),
      ),
    );
  }
}