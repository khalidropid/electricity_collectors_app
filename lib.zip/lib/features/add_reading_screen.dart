import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/customer.dart';
import '../models/reading.dart';
import '../providers/reading_provider.dart';

class AddReadingScreen extends StatefulWidget {
  final Customer customer; // استقبال بيانات المشترك

  const AddReadingScreen({super.key, required this.customer});

  @override
  State<AddReadingScreen> createState() => _AddReadingScreenState();
}

class _AddReadingScreenState extends State<AddReadingScreen> {
  // متغيرات القراءة
  double _previousReading = 0.0;
  bool _isLoadingPrevious = true; // مؤشر تحميل القراءة السابقة
  final TextEditingController _currentReadingController =
      TextEditingController();
  double _consumption = 0.0;

  // متغيرات الصورة
  File? _meterImage;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    // جلب القراءة السابقة من جدول take_up_chits في السيرفر فور فتح الشاشة
    _fetchPreviousReadingFromServer();

    // لتحديث قيمة الاستهلاك تلقائياً عند الكتابة
    _currentReadingController.addListener(_calculateConsumption);
  }

  @override
  void dispose() {
    _currentReadingController.dispose();
    super.dispose();
  }

  // 🌟 الدالة المحدثة: جلب القراءة بناءً على أحدث سنة وأحدث شهر
  Future<void> _fetchPreviousReadingFromServer() async {
    try {
      final supabase = Supabase.instance.client;

      final response = await supabase
          .from('take_up_chits')
          .select('last_read, year, id_month') // جلبنا السنة والشهر للتأكد
          .eq('id_customer', widget.customer.id)
          // 1. الترتيب حسب السنة التنازلي (الأحدث أولاً)
          .order('year', ascending: false)
          // 2. الترتيب حسب الشهر التنازلي (الأحدث أولاً في نفس السنة)
          .order('id_month', ascending: false)
          .limit(1)
          .maybeSingle();

      if (response != null && response['last_read'] != null) {
        debugPrint(
            '===> تم جلب القراءة السابقة بنجاح. السنة: ${response['year']}، الشهر: ${response['id_month']}');

        setState(() {
          _previousReading = (response['last_read'] as num).toDouble();
          _isLoadingPrevious = false;
        });
      } else {
        // إذا لم توجد قراءة سابقة مسجلة (مشترك جديد)
        debugPrint('===> لا توجد قراءة سابقة لهذا المشترك.');
        setState(() {
          _previousReading = 0.0;
          _isLoadingPrevious = false;
        });
      }
    } catch (e) {
      debugPrint('===> خطأ في جلب القراءة السابقة: $e');
      setState(() {
        _previousReading = 0.0;
        _isLoadingPrevious = false;
      });
    }
  }

  // دالة التقاط صورة العداد
  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );

      if (pickedFile != null) {
        setState(() {
          _meterImage = File(pickedFile.path);
        });
      }
    } catch (e) {
      debugPrint('Error picking image: $e');
    }
  }

  // دالة تحويل الأرقام العربية إلى إنجليزية
  String _normalizeNumbers(String input) {
    const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
    const englishNumbers = '0123456789';
    String result = input;
    for (int i = 0; i < arabicNumbers.length; i++) {
      result = result.replaceAll(arabicNumbers[i], englishNumbers[i]);
    }
    return result;
  }

  void _calculateConsumption() {
    String normalizedInput = _normalizeNumbers(_currentReadingController.text);
    double current = double.tryParse(normalizedInput) ?? 0.0;

    setState(() {
      if (current >= _previousReading) {
        _consumption = current - _previousReading;
      } else {
        _consumption = 0.0;
      }
    });
  }

  void _saveData() async {
    if (_consumption <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('الرجاء إدخال قراءة صحيحة أكبر من القراءة السابقة'),
            backgroundColor: Colors.red),
      );
      return;
    }

    Reading newReading = Reading(
      id: 0,
      subscriberId: widget.customer.id,
      meterId: int.tryParse(widget.customer.meterNo ?? '0') ?? 1,
      previousReading: _previousReading,
      currentReading:
          double.parse(_normalizeNumbers(_currentReadingController.text)),
      consumption: _consumption,
      readingDate: DateTime.now().toString().substring(0, 10),
      status: 'pending',
    );

    final provider = Provider.of<ReadingProvider>(context, listen: false);
    bool success =
        await provider.saveReading(newReading, imageFile: _meterImage);

    if (mounted) {
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تم حفظ وتخزين القراءة بنجاح!'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('حدث خطأ أثناء حفظ القراءة.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    String todayDate = DateTime.now().toString().substring(0, 10);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          title: Text(
            'تسجيل قراءة',
            style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 20.h),
          child: Column(
            children: [
              // 1. بيانات المشترك العلوية
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      'المشترك: ${widget.customer.name}',
                      style: TextStyle(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Text(
                    'العداد: ${widget.customer.meterNo ?? "غير متوفر"}',
                    style: TextStyle(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87),
                  ),
                ],
              ),
              SizedBox(height: 25.h),

              // 2. حقول القراءة (مع عرض مؤشر تحميل أثناء جلب القراءة السابقة)
              _isLoadingPrevious
                  ? Container(
                      padding: EdgeInsets.symmetric(vertical: 15.h),
                      child: const Center(child: CircularProgressIndicator()),
                    )
                  : _buildReadOnlyField(
                      'القراءة السابقة', _previousReading.toInt().toString()),
              SizedBox(height: 15.h),

              _buildInputField('القراءة الحالية', _currentReadingController),
              SizedBox(height: 15.h),

              _buildReadOnlyField(
                  'الاستهلاك', '${_consumption.toInt()} كيلو وات'),
              SizedBox(height: 15.h),

              _buildReadOnlyField('تاريخ القراءة', todayDate),
              SizedBox(height: 25.h),

              // 3. قسم الصورة والموقع
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 15.h),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(8.r),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () => _showImageSourceDialog(),
                            child: Row(
                              children: [
                                Container(
                                  padding: EdgeInsets.all(8.w),
                                  decoration: BoxDecoration(
                                    color: Colors.blue.shade50,
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(Icons.camera_alt,
                                      color: Colors.blue, size: 20.w),
                                ),
                                SizedBox(width: 5.w),
                                Expanded(
                                  child: Text(
                                    _meterImage == null
                                        ? 'التقاط صورة للعداد'
                                        : 'تم التقاط الصورة ✓',
                                    style: TextStyle(
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.bold,
                                        color: _meterImage == null
                                            ? Colors.black87
                                            : Colors.green),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Expanded(
                                child: Text(
                                  '13.5795 , 44.0209', // الإحداثيات (سيتم برمجتها لاحقاً)
                                  textAlign: TextAlign.end,
                                  style: TextStyle(
                                      fontSize: 11.sp,
                                      color: Colors.grey.shade600),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                ),
                              ),
                              SizedBox(width: 5.w),
                              Icon(Icons.location_on,
                                  color: Colors.blue, size: 20.w),
                            ],
                          ),
                        ),
                      ],
                    ),
                    if (_meterImage != null) ...[
                      SizedBox(height: 15.h),
                      Stack(
                        alignment: Alignment.topRight,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8.r),
                            child: Image.file(
                              _meterImage!,
                              height: 120.h,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                          IconButton(
                            icon: const CircleAvatar(
                              backgroundColor: Colors.red,
                              child: Icon(Icons.close,
                                  color: Colors.white, size: 18),
                            ),
                            onPressed: () {
                              setState(() {
                                _meterImage = null;
                              });
                            },
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),

              SizedBox(height: 40.h),

              // 4. زر حفظ القراءة
              Consumer<ReadingProvider>(builder: (context, provider, child) {
                return SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: provider.isLoading ? null : _saveData,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: EdgeInsets.symmetric(vertical: 15.h),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                    ),
                    child: provider.isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(
                            'حفظ القراءة',
                            style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }

  void _showImageSourceDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('اختر مصدر الصورة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Colors.blue),
              title: const Text('الكاميرا'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Colors.green),
              title: const Text('معرض الصور'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReadOnlyField(String label, String value) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.h),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
                fontSize: 14.sp,
                color: Colors.grey.shade600,
                fontWeight: FontWeight.w600),
          ),
          Text(
            value,
            style: TextStyle(
                fontSize: 14.sp,
                color: Colors.black87,
                fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField(String label, TextEditingController controller) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.green, width: 1.5),
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        children: [
          Padding(
            padding: EdgeInsets.only(right: 15.w),
            child: Text(
              label,
              style: TextStyle(
                  fontSize: 14.sp,
                  color: Colors.green,
                  fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.left,
              style: TextStyle(
                  fontSize: 16.sp,
                  color: Colors.black87,
                  fontWeight: FontWeight.bold),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.h),
                hintText: '0',
                hintStyle: TextStyle(color: Colors.grey.shade400),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
