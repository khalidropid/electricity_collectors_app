import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../database/database_helper.dart';
import '../core/utils/secure_storage_helper.dart';
import '../widgets/app_drawer.dart';

class ModificationRequestScreen extends StatefulWidget {
  final String? initialSubNo;
  final String? initialName;
  final String? initialAddress;

  const ModificationRequestScreen({
    super.key,
    this.initialSubNo,
    this.initialName,
    this.initialAddress,
  });

  @override
  State<ModificationRequestScreen> createState() =>
      _ModificationRequestScreenState();
}

class _ModificationRequestScreenState extends State<ModificationRequestScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _subNoController;
  late TextEditingController _nameController;
  late TextEditingController _addressController;
  late TextEditingController _notesController;

  String _selectedModType = 'تعديل اسم';
  final List<String> _modTypes = [
    'تعديل اسم',
    'تعديل عنوان',
    'خطأ في العداد',
    'أخرى'
  ];

  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _subNoController = TextEditingController(text: widget.initialSubNo ?? '');
    _nameController = TextEditingController(text: widget.initialName ?? '');
    _addressController =
        TextEditingController(text: widget.initialAddress ?? '');
    _notesController = TextEditingController();
  }

  @override
  void dispose() {
    _subNoController.dispose();
    _nameController.dispose();
    _addressController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _submitRequest() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSubmitting = true);

    try {
      String? empIdStr = await SecureStorageHelper.getEmpId();
      int empId = int.parse(empIdStr ?? '0');
      int customerId = int.tryParse(_subNoController.text) ?? 0;

      // تجهيز البيانات للحفظ المحلي
      Map<String, dynamic> requestData = {
        'emp_id': empId,
        'id_customer': customerId,
        'name_customer': _nameController.text,
        'address_customer': _addressController.text,
        'mod_type': _selectedModType,
        'notes': _notesController.text,
        'request_date': DateTime.now().toIso8601String(), 
        'status': 'pending', 
      };

      // الحفظ في قاعدة البيانات المحلية (SQLite)
      final db = await DatabaseHelper().database;
      await db.insert('modification_requests', requestData);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تم حفظ الطلب محلياً وسيتم إرساله للإدارة عند المزامنة ✓'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context); // العودة بعد النجاح
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('حدث خطأ أثناء حفظ الطلب: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isSubmitting = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),
        drawer: const AppDrawer(),
        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          title: Text('طلب تعديل بيانات',
              style: TextStyle(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.white)),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
          leading: Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: Colors.white),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.arrow_forward_ios, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.all(20.w),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.all(12.w),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(10.r),
                    border: Border.all(color: Colors.blue.shade100),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline, color: Colors.blue),
                      SizedBox(width: 10.w),
                      Expanded(
                        child: Text(
                            'يرجى تعبئة بيانات الطلب وسوف يتم حفظه ومراجعته من قبل الإدارة بعد المزامنة.',
                            style: TextStyle(
                                fontSize: 13.sp, color: Colors.blue.shade900)),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20.h),

                // حقل رقم المشترك
                _buildTextField(
                    controller: _subNoController,
                    label: 'رقم المشترك',
                    icon: Icons.numbers,
                    isNumber: true), // 🌟 تحديد أنه أرقام فقط
                SizedBox(height: 15.h),

                // حقل اسم المشترك
                _buildTextField(
                    controller: _nameController,
                    label: 'الاسم الصحيح / الجديد',
                    icon: Icons.person_outline),
                SizedBox(height: 15.h),

                // حقل العنوان
                _buildTextField(
                    controller: _addressController,
                    label: 'العنوان الصحيح',
                    icon: Icons.location_on_outlined),
                SizedBox(height: 15.h),

                // القائمة المنسدلة لنوع التعديل
                DropdownButtonFormField<String>(
                  value: _selectedModType,
                  decoration: InputDecoration(
                    labelText: 'نوع التعديل',
                    filled: true,
                    fillColor: Colors.white,
                    prefixIcon: const Icon(Icons.category, color: Colors.grey),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.r),
                        borderSide: BorderSide(color: Colors.grey.shade300)),
                  ),
                  items: _modTypes
                      .map((type) =>
                          DropdownMenuItem(value: type, child: Text(type)))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setState(() => _selectedModType = value);
                  },
                ),
                SizedBox(height: 15.h),

                // حقل الملاحظات / التفاصيل
                TextFormField(
                  controller: _notesController,
                  maxLines: 3,
                  validator: (value) => value == null || value.isEmpty
                      ? 'يرجى كتابة التعديل المطلوب'
                      : null,
                  decoration: InputDecoration(
                    labelText: 'التعديل المطلوب بالتفصيل',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.r)),
                  ),
                ),
                SizedBox(height: 30.h),

                // زر الحفظ
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isSubmitting ? null : _submitRequest,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1A5276),
                      padding: EdgeInsets.symmetric(vertical: 15.h),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.r)),
                    ),
                    child: _isSubmitting
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text('حفظ الطلب',
                            style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                                color: Colors.white)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isNumber = false,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text, // 🌟 لوحة مفاتيح ديناميكية
      validator: (value) =>
          value == null || value.isEmpty ? 'هذا الحقل مطلوب' : null,
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        prefixIcon: Icon(icon, color: Colors.grey),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.r),
            borderSide: BorderSide(color: Colors.grey.shade300)),
      ),
    );
  }
}