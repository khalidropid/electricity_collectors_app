import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:blue_thermal_printer/blue_thermal_printer.dart'; // حزمة الطباعة الحرارية

import '../models/customer.dart';
import '../models/payment.dart';

class InvoiceScreen extends StatefulWidget {
  final Customer customer;
  final Payment payment;

  const InvoiceScreen({super.key, required this.customer, required this.payment});

  @override
  State<InvoiceScreen> createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> {
  // متغيرات الطابعة
  BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;
  List<BluetoothDevice> _devices = [];
  BluetoothDevice? _selectedDevice;
  bool _connected = false;

  @override
  void initState() {
    super.initState();
    _initBluetooth();
  }

  // تهيئة البلوتوث وجلب الأجهزة المقترنة
  void _initBluetooth() async {
    bool? isConnected = await bluetooth.isConnected;
    List<BluetoothDevice> devices = [];
    try {
      devices = await bluetooth.getBondedDevices();
    } catch (e) {
      debugPrint("Error fetching devices: $e");
    }

    bluetooth.onStateChanged().listen((state) {
      switch (state) {
        case BlueThermalPrinter.CONNECTED:
          setState(() => _connected = true);
          break;
        case BlueThermalPrinter.DISCONNECTED:
          setState(() => _connected = false);
          break;
        default:
          break;
      }
    });

    if (!mounted) return;
    setState(() {
      _devices = devices;
      _connected = isConnected ?? false;
    });
  }

  // نافذة لاختيار الطابعة
  void _showPrinterDialog() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20.r))),
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(20.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('اختر طابعة البلوتوث', style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold)),
              SizedBox(height: 15.h),
              _devices.isEmpty
                  ? const Text('لم يتم العثور على طابعات مقترنة.')
                  : Expanded(
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: _devices.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            leading: const Icon(Icons.print, color: Colors.blue),
                            title: Text(_devices[index].name ?? 'طابعة غير معروفة'),
                            subtitle: Text(_devices[index].address ?? ''),
                            onTap: () async {
                              Navigator.pop(context);
                              _connectAndPrint(_devices[index]);
                            },
                          );
                        },
                      ),
                    ),
            ],
          ),
        );
      },
    );
  }

  // الاتصال بالطابعة وبدء الطباعة
  void _connectAndPrint(BluetoothDevice device) async {
    if (_connected) {
      await bluetooth.disconnect();
    }
    
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('جاري الاتصال بالطابعة...')));
    
    try {
      await bluetooth.connect(device);
      _printReceiptData();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل الاتصال: $e'), backgroundColor: Colors.red));
    }
  }

  // تصميم الورقة المطبوعة (البيانات التي سترسل للطابعة)
  void _printReceiptData() {
    bluetooth.isConnected.then((isConnected) {
      if (isConnected == true) {
        double arrears = widget.customer.arrears ?? 0.0;
        double remaining = arrears - widget.payment.amount;
        if (remaining < 0) remaining = 0;

        bluetooth.printNewLine();
        bluetooth.printCustom("سند تحصيل - Receipt", 2, 1);
        bluetooth.printNewLine();
        
        bluetooth.printCustom("Receipt No: ${widget.payment.receiptNo}", 1, 1);
        bluetooth.printCustom("Date: ${widget.payment.paymentDate}", 1, 1);
        bluetooth.printNewLine();
        
        // الطابعات الحرارية أحياناً تواجه مشكلة مع الحروف العربية، يفضل إرسالها بتشفير معين أو كصورة
        // هنا نرسلها كنص مباشر مع دعم الترميز الافتراضي
        bluetooth.printCustom("Customer: ${widget.customer.name}", 1, 0);
        bluetooth.printCustom("Meter No: ${widget.customer.meterNo ?? 'N/A'}", 1, 0);
        bluetooth.printCustom("Payment Method: ${widget.payment.paymentMethod}", 1, 0);
        bluetooth.printNewLine();
        
        bluetooth.printCustom("--------------------------------", 1, 1);
        bluetooth.printCustom("Previous Debt: $arrears", 1, 0);
        bluetooth.printCustom("Paid Amount: ${widget.payment.amount}", 2, 1); // خط عريض للمبلغ
        bluetooth.printCustom("Remaining: $remaining", 1, 0);
        bluetooth.printCustom("--------------------------------", 1, 1);
        
        bluetooth.printNewLine();
        bluetooth.printCustom("Thank You - شكرا لكم", 1, 1);
        bluetooth.printNewLine();
        bluetooth.printNewLine();
        bluetooth.paperCut(); // قص الورقة إذا كانت الطابعة تدعم ذلك
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    double arrears = widget.customer.arrears ?? 0.0;
    double remaining = arrears - widget.payment.amount;
    if (remaining < 0) remaining = 0;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),
        appBar: AppBar(
          backgroundColor: const Color(0xFF1A5276),
          title: Text(
            'سند تحصيل',
            style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
          automaticallyImplyLeading: false, // منع الرجوع المباشر
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(20.w),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12.r),
                  boxShadow: [
                    BoxShadow(color: Colors.grey.withOpacity(0.1), blurRadius: 5, offset: const Offset(0, 2)),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          widget.payment.receiptNo,
                          style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold, color: Colors.black87),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                          decoration: BoxDecoration(
                            color: Colors.green.shade50,
                            borderRadius: BorderRadius.circular(4.r),
                            border: Border.all(color: Colors.green.shade200),
                          ),
                          child: Text(
                            'تم الدفع',
                            style: TextStyle(fontSize: 12.sp, color: Colors.green.shade700, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h),
                    _buildInfoRow('المشترك', widget.customer.name),
                    _buildInfoRow('رقم العداد', widget.customer.meterNo ?? 'غير متوفر'),
                    _buildInfoRow('تاريخ السند', widget.payment.paymentDate),
                    Divider(height: 30.h, color: Colors.grey.shade300, thickness: 1),
                    _buildDetailRow('طريقة الدفع', widget.payment.paymentMethod),
                    _buildDetailRow('إجمالي الديون السابقة', '$arrears'),
                    _buildDetailRow('المبلغ المدفوع', '${widget.payment.amount}'),
                    _buildDetailRow('المتبقي عليه', '$remaining'),
                    Divider(height: 30.h, color: Colors.grey.shade300, thickness: 1),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('المستلم الفعلي', style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold, color: Colors.black87)),
                        Text('${widget.payment.amount} ريال', style: TextStyle(fontSize: 20.sp, fontWeight: FontWeight.bold, color: Colors.green.shade700)),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 40.h),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: ElevatedButton(
                      onPressed: _showPrinterDialog, // استدعاء نافذة الطباعة هنا
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: EdgeInsets.symmetric(vertical: 15.h),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.r)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.print, color: Colors.white),
                          SizedBox(width: 8.w),
                          Text('طباعة', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold, color: Colors.white)),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(width: 15.w),
                  Expanded(
                    flex: 1,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).popUntil((route) => route.isFirst);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1A5276),
                        padding: EdgeInsets.symmetric(vertical: 15.h),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.r)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.home, color: Colors.white),
                          SizedBox(width: 8.w),
                          Text('الرئيسية', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold, color: Colors.white)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 13.sp, color: Colors.grey.shade600)),
          Text(value, style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.bold, color: Colors.black87)),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.bold, color: Colors.black87)),
          Text(value, style: TextStyle(fontSize: 14.sp, color: Colors.grey.shade800)),
        ],
      ),
    );
  }
}