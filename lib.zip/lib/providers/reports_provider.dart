import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';

class ReportsProvider with ChangeNotifier {
  bool _isLoading = false;
  double _totalCollectedToday = 0.0;
  int _paymentsCountToday = 0;
  int _readingsCountToday = 0;

  bool get isLoading => _isLoading;
  double get totalCollectedToday => _totalCollectedToday;
  int get paymentsCountToday => _paymentsCountToday;
  int get readingsCountToday => _readingsCountToday;

  Future<void> loadDailyReport() async {
    _isLoading = true;
    notifyListeners();

    try {
      final db = await DatabaseHelper().database;
      
      // نجلب تاريخ اليوم بصيغة (مثال: 2026-09-08)
      String todayDate = DateFormat('yyyy-MM-dd').format(DateTime.now());

      // 1. حساب إجمالي النقدية المحصلة اليوم
      // نستخدم LIKE للبحث عن أي سجل يحمل تاريخ اليوم في بدايته
      final sumResult = await db.rawQuery(
        "SELECT SUM(amount) as total FROM collections WHERE payment_date LIKE ?", 
        ['$todayDate%']
      );
      _totalCollectedToday = (sumResult.first['total'] as num?)?.toDouble() ?? 0.0;

      // 2. حساب عدد السندات (التحصيلات) لليوم
      final paymentsCountResult = await db.rawQuery(
        "SELECT COUNT(*) as count FROM collections WHERE payment_date LIKE ?", 
        ['$todayDate%']
      );
      _paymentsCountToday = (paymentsCountResult.first['count'] as int?) ?? 0;

      // 3. حساب عدد القراءات لليوم
      // (ملاحظة: افترضنا أن اسم عمود التاريخ في جدول القراءات هو reading_date، إذا كان مختلفاً قم بتعديله هنا)
      final readingsCountResult = await db.rawQuery(
        "SELECT COUNT(*) as count FROM readings WHERE reading_date LIKE ?", 
        ['$todayDate%']
      );
      _readingsCountToday = (readingsCountResult.first['count'] as int?) ?? 0;

    } catch (e) {
      debugPrint("خطأ في جلب تقارير اليوم: $e");
      // تصفير القيم في حال حدوث خطأ
      _totalCollectedToday = 0.0;
      _paymentsCountToday = 0;
      _readingsCountToday = 0;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}