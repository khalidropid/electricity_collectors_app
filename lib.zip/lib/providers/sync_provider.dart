import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../database/database_helper.dart';
import '../core/utils/secure_storage_helper.dart';
import '../models/reading.dart';
import '../models/payment.dart';

class SyncProvider with ChangeNotifier {
  bool _isSyncing = false;
  String _syncStatus = 'جاهز للمزامنة';

  int _sentCount = 0;
  int _receivedCount = 0;
  int _updatedCount = 0;

  bool get isSyncing => _isSyncing;
  String get syncStatus => _syncStatus;
  int get sentCount => _sentCount;
  int get receivedCount => _receivedCount;
  int get updatedCount => _updatedCount;

  final _supabase = Supabase.instance.client;

  Future<void> syncData() async {
    _isSyncing = true;
    _syncStatus = 'جاري بدء المزامنة...';

    _sentCount = 0;
    _receivedCount = 0;
    _updatedCount = 0;
    notifyListeners();

    try {
      final db = await DatabaseHelper().database;
      
      String? empIdStr = await SecureStorageHelper.getEmpId();
      int empId = int.tryParse(empIdStr ?? '0') ?? 0;

      // ==========================================
      // 1. رفع البيانات المعلقة للسيرفر (Push)
      // ==========================================

      // أ. رفع السندات (التحصيلات)
      _syncStatus = 'جاري رفع السندات المعلقة...';
      notifyListeners();

      final pendingPayments = await db.query('collections', where: 'status = ?', whereArgs: ['pending']);
      for (var map in pendingPayments) {
        Payment payment = Payment.fromMap(map);
        await _supabase.from('app_collections').insert(payment.toServerMap());
        await db.update('collections', {'status': 'synced'}, where: 'id = ?', whereArgs: [payment.id]);
        _sentCount++;
      }

      // ب. رفع القراءات
      _syncStatus = 'جاري رفع القراءات المعلقة...';
      notifyListeners();

      final pendingReadings = await db.query('readings', where: 'status = ?', whereArgs: ['pending']);
      for (var map in pendingReadings) {
        Reading reading = Reading.fromMap(map);
        await _supabase.from('app_readings').insert(reading.toServerMap(empId));
        await db.update('readings', {'status': 'synced'}, where: 'id = ?', whereArgs: [reading.id]);
        _sentCount++;
      }

      // ج. رفع طلبات التعديل
      _syncStatus = 'جاري رفع طلبات التعديل...';
      notifyListeners();

      final pendingMods = await db.query('modification_requests', where: 'status = ?', whereArgs: ['pending']);
      for (var map in pendingMods) {
        Map<String, dynamic> serverData = Map<String, dynamic>.from(map);
        int localId = serverData.remove('id');
        serverData.remove('status');

        // 🌟 تم التعديل هنا: اسم الجدول modification_requests
        await _supabase.from('modification_requests').insert(serverData);
        await db.update('modification_requests', {'status': 'synced'}, where: 'id = ?', whereArgs: [localId]);
        _sentCount++;
      }

      // ==========================================
      // 2. تنزيل بيانات المشتركين (Pull)
      // ==========================================
      _syncStatus = 'جاري تحديث بيانات المشتركين والديون...';
      notifyListeners();

      final customersData = await _supabase
          .from('app_customers')
          .select();

      if (customersData.isNotEmpty) {
        await db.delete('customers'); 
        for (var customerMap in customersData) {
          await db.insert('customers', customerMap);
        }
        
        _receivedCount = customersData.length;
        _updatedCount = customersData.length;
      }

      _syncStatus = 'تمت المزامنة بنجاح ✓';
    } catch (e) {
      _syncStatus = 'فشل المزامنة! يرجى التحقق من الإنترنت.';
      debugPrint('Sync Error: $e');
    } finally {
      _isSyncing = false;
      notifyListeners();
    }
  }
}