import 'package:flutter/material.dart';
import '../models/payment.dart';
import '../database/database_helper.dart';

class PaymentProvider with ChangeNotifier {
  bool _isLoading = false;

  bool get isLoading => _isLoading;

  Future<bool> savePayment(Payment payment) async {
    _isLoading = true;
    notifyListeners();

    try {
      // 1. تحديد حالة السند الافتراضية
      String finalStatus = 'pending';

      // 2. محاولة الرفع للسيرفر أولاً (Supabase)
      try {
        // استخدام دالة toServerMap التي تطابق أعمدة جدول app_collections بدقة
        // final serverData = payment.toServerMap();
        // await Supabase.instance.client.from('app_collections').insert(serverData);

        // لمحاكاة انقطاع الإنترنت أو فشل السيرفر، سنترك الخطأ مقصوداً للعمل Offline
        throw Exception('No Internet Connection');

        // إذا تم الرفع بنجاح:
        // finalStatus = 'synced';
      } catch (e) {
        debugPrint('فشل الرفع للسيرفر، سيتم الحفظ محلياً كبيانات معلقة: $e');
        finalStatus = 'pending';
      }

      // 3. الحفظ في قاعدة البيانات المحلية (SQLite) باستخدام toMap()
      final db = await DatabaseHelper().database;

      // تجهيز خريطة البيانات مع تحديث الحالة النهائية (معلق أو متزامن)
      Map<String, dynamic> paymentMap = payment.toMap();
      paymentMap['status'] = finalStatus;

      // إضافة السند إلى جدول التحصيلات محلياً
      await db.insert('collections', paymentMap);

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('خطأ فادح في حفظ سند القبض محلياً: $e');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }
}