import 'dart:io';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/reading.dart';
import '../database/database_helper.dart';

class ReadingProvider with ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  // دالة حفظ القراءة
  Future<bool> saveReading(Reading reading, {File? imageFile}) async {
    _isLoading = true;
    notifyListeners();

    try {
      final supabase = Supabase.instance.client;
      String? uploadedImageUrl;

      // 1. محاولة رفع الصورة للسيرفر إذا توفرت إنترنت
      if (imageFile != null && await _hasNetwork()) {
        final fileName = 'meter_${DateTime.now().millisecondsSinceEpoch}.jpg';
        
        await supabase.storage.from('meter_images').upload(
              fileName,
              imageFile,
              fileOptions: const FileOptions(upsert: false),
            );

        uploadedImageUrl = supabase.storage
            .from('meter_images')
            .getPublicUrl(fileName);
      }

      // 2. محاولة الحفظ المباشر في Supabase أونلاين
      if (await _hasNetwork()) {
        await supabase.from('readings').insert({
          'subscriber_id': reading.subscriberId,
          'previous_reading': reading.previousReading,
          'current_reading': reading.currentReading,
          'consumption': reading.consumption,
          'reading_date': reading.readingDate,
          'status': 'synced',
          'image_url': uploadedImageUrl,
        });

        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        throw Exception('No Internet');
      }
    } catch (e) {
      debugPrint('الحفظ محلياً في SQLite بسبب عدم توفر الإنترنت: $e');

      // 3. الحفظ المحلي في SQLite في حالة انقطاع الإنترنت
      try {
        final db = await DatabaseHelper().database;
        await db.insert('readings', {
          'subscriber_id': reading.subscriberId,
          'meter_id': reading.meterId,
          'previous_reading': reading.previousReading,
          'current_reading': reading.currentReading,
          'consumption': reading.consumption,
          'reading_date': reading.readingDate,
          'status': 'pending', // معلقة للمزامنة لاحقاً
          'image_path': imageFile?.path, // مسار الصورة المحلي
        });

        _isLoading = false;
        notifyListeners();
        return true; // نجح الحفظ محلياً
      } catch (localError) {
        debugPrint('خطأ SQLite محلي: $localError');
        _isLoading = false;
        notifyListeners();
        return false;
      }
    }
  }

  // فحص بسيط للاتصال بالإنترنت
  Future<bool> _hasNetwork() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      return result.isNotEmpty && result[0].rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }
}