import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/customer.dart';

class CustomerProvider with ChangeNotifier {
  List<Customer> _allCustomers = [];
  List<Customer> _searchResults = [];
  bool _isLoading = false;

  List<Customer> get searchResults => _searchResults;
  bool get isLoading => _isLoading;

  // 🌟 دالة مساعدة لتعيين بيانات العملاء بناءً على هيكل قاعدتك بالضبط
  void _mapAndSetCustomers(List<Map<String, dynamic>> allFetchedData) {
    _allCustomers = allFetchedData.map((map) {
      return Customer(
        id: map['id_customer'] ?? 0,
        subscriberNo: (map['num_account'] ?? '').toString(),
        name: map['name_customer'] ?? 'بدون اسم',
        phone: (map['num_phone'] ?? '').toString(),
        meterNo: (map['num_addaad'])?.toString(),
        areaId: map['id_state'] ?? 1,
        status: 'active',
        address: map['address_customer'] ?? map['street_customer'] ?? '',
        arrears: 0.0,
        lastConsumption: 0,
        lastMonth: '',
      );
    }).toList();

    _searchResults = _allCustomers;
  }

  // 🌟 جلب كافة العملاء من السيرفر (بدون فلترة)
  Future<void> loadCustomers() async {
    _isLoading = true;
    notifyListeners();

    try {
      debugPrint('===> جاري جلب جميع العملاء...');
      final supabase = Supabase.instance.client;
      List<Map<String, dynamic>> allFetchedData = [];
      int pageSize = 1000;
      int from = 0;
      bool hasMore = true;

      while (hasMore) {
        final List<dynamic> response = await supabase
            .from('customer')
            .select()
            .range(from, from + pageSize - 1);

        if (response.isNotEmpty) {
          allFetchedData.addAll(response.cast<Map<String, dynamic>>());
          if (response.length < pageSize) {
            hasMore = false;
          } else {
            from += pageSize;
          }
        } else {
          hasMore = false;
        }
      }
      _mapAndSetCustomers(allFetchedData);
      debugPrint('===> تم جلب ${allFetchedData.length} عميل بنجاح.');
    } catch (e) {
      debugPrint('===> خطأ في جلب كل العملاء: $e');
      _allCustomers = [];
      _searchResults = [];
    }

    _isLoading = false;
    notifyListeners();
  }

  // 🌟 جلب العملاء بناءً على المناطق المربوطة بالمتحصل (مطابق لقاعدتك 100%)
  Future<void> loadCustomersForCollector(int empId) async {
    _isLoading = true;
    notifyListeners();

    try {
      final supabase = Supabase.instance.client;

      debugPrint('===> 1. البحث في streets_line عن id_emp = $empId');

      // 1. جلب الشوارع المرتبطة بالموظف من جدول streets_line
      final streetsResponse = await supabase
          .from('streets_line')
          .select('street_customer')
          .eq('id_emp', empId); // اسم العمود في قاعدتك هو id_emp

      // 2. استخراج أسماء الشوارع (street_customer)
      List<String> streetNames = (streetsResponse as List)
          .map((street) => street['street_customer'].toString())
          .where((street) => street.isNotEmpty && street != 'null')
          .toList();

      debugPrint('===> 2. الشوارع الخاصة بهذا المتحصل: $streetNames');

      if (streetNames.isEmpty) {
        debugPrint('===> تنبيه: هذا الموظف ليس لديه أي شوارع في streets_line!');
        _allCustomers = [];
        _searchResults = [];
        _isLoading = false;
        notifyListeners();
        return;
      }

      // 3. جلب العملاء الذين ينتمون لهذه الشوارع (على دفعات لتجاوز 1000 سجل)
      List<Map<String, dynamic>> allFetchedData = [];
      int pageSize = 1000;
      int from = 0;
      bool hasMore = true;

      while (hasMore) {
        // نستخدم in_ للبحث في عمود street_customer ضمن جدول customer
        final List<dynamic> response = await supabase
            .from('customer')
            .select()
            .inFilter('street_customer', streetNames)
            .range(from, from + pageSize - 1);

        if (response.isNotEmpty) {
          allFetchedData.addAll(response.cast<Map<String, dynamic>>());
          if (response.length < pageSize) {
            hasMore = false;
          } else {
            from += pageSize;
          }
        } else {
          hasMore = false;
        }
      }

      debugPrint(
          '===> 3. تم جلب عدد العملاء المرتبطين بمناطق هذا المتحصل: ${allFetchedData.length}');
      _mapAndSetCustomers(allFetchedData);
    } catch (e) {
      debugPrint('===> ❌ خطأ في جلب عملاء المتحصل حسب الصلاحيات: $e');
      _allCustomers = [];
      _searchResults = [];
    }

    _isLoading = false;
    notifyListeners();
  }

  // دوال التنظيف والبحث المحلي السريع
  String _normalizeNumbers(String input) {
    const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
    const englishNumbers = '0123456789';
    String result = input;
    for (int i = 0; i < arabicNumbers.length; i++) {
      result = result.replaceAll(arabicNumbers[i], englishNumbers[i]);
    }
    return result;
  }

  String _cleanText(String input) {
    return _normalizeNumbers(input)
        .replaceAll(RegExp(r'[أإآا]'), 'ا')
        .replaceAll(RegExp(r'[ةه]'), 'ه')
        .replaceAll(RegExp(r'ى'), 'ي')
        .trim()
        .toLowerCase();
  }

  void search(String query) {
    if (query.isEmpty) {
      _searchResults = _allCustomers;
    } else {
      String cleanQuery = _cleanText(query);

      _searchResults = _allCustomers.where((customer) {
        String cleanName = _cleanText(customer.name);
        String cleanPhone = _cleanText(customer.phone);
        String cleanMeter = _cleanText(customer.meterNo ?? '');
        String cleanSubNo = _cleanText(customer.subscriberNo);

        return cleanName.contains(cleanQuery) ||
            cleanPhone.contains(cleanQuery) ||
            cleanMeter.contains(cleanQuery) ||
            cleanSubNo.contains(cleanQuery);
      }).toList();
    }
    notifyListeners();
  }
}
