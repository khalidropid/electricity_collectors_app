import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:sqflite/sqflite.dart';

import '../core/utils/secure_storage_helper.dart';
import '../database/database_helper.dart';

class AuthProvider with ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  // --- دالة تسجيل الدخول (Online & Offline) ---
  Future<bool> login(String username, String password) async {
    _isLoading = true;
    notifyListeners();

    try {
      final supabase = Supabase.instance.client;

      debugPrint('--- جاري البحث عن المستخدم: $username ---');

      final authResponse = await supabase
          .from('app_collectors')
          .select()
          .eq('username', username)
          .eq('password', password)
          .maybeSingle();

      debugPrint('--- نتيجة الاستعلام من Supabase: $authResponse ---');

      if (authResponse != null) {
        // فحص مرن لحالة التفعيل (سواء كان true كـ boolean أو 1 كـ رقم)
        var isActive = authResponse['is_active'];
        bool isUserActive = (isActive == true || isActive == 1);

        debugPrint('--- هل المستخدم مفعل؟ $isUserActive (القيمة الأصلية: $isActive) ---');

        if (isUserActive) {
          int empId = authResponse['emp_id'];

          final empResponse = await supabase
              .from('employees')
              .select('name_emp')
              .eq('id_emp', empId)
              .maybeSingle();

          String empName =
              empResponse != null ? empResponse['name_emp'] : 'متحصل مجهول';

          final db = await DatabaseHelper().database;
          await db.insert(
            'employees',
            {
              'id_emp': empId,
              'name_emp': empName,
              'username': username,
              'password': password,
            },
            conflictAlgorithm: ConflictAlgorithm.replace,
          );

          await SecureStorageHelper.saveCollectorData(empId.toString(), empName);

          _isLoading = false;
          notifyListeners();
          return true;
        } else {
          debugPrint('خطأ: الحساب موجود لكن حقل is_active غير مفعل أو مسجل كـ false/0');
        }
      } else {
        debugPrint('خطأ: اسم المستخدم أو كلمة المرور غير مطابقة تماماً في القاعدة');
      }
    } catch (e) {
      debugPrint('Supabase Login Error: $e');
    }

    // 2. المحاولة المحلية (Offline) في حال انقطاع الإنترنت
    try {
      final db = await DatabaseHelper().database;
      final List<Map<String, dynamic>> localUsers = await db.query(
        'employees',
        where: 'username = ? AND password = ?',
        whereArgs: [username, password],
      );

      if (localUsers.isNotEmpty) {
        int empId = localUsers.first['id_emp'];
        String empName = localUsers.first['name_emp'];

        await SecureStorageHelper.saveCollectorData(empId.toString(), empName);

        _isLoading = false;
        notifyListeners();
        return true;
      }
    } catch (e) {
      debugPrint('Local SQLite Login Error: $e');
    }

    _isLoading = false;
    notifyListeners();
    return false;
  }

  // --- دالة تغيير كلمة المرور ---
  Future<bool> changePassword(String oldPassword, String newPassword) async {
    _isLoading = true;
    notifyListeners();

    try {
      String? empIdStr = await SecureStorageHelper.getEmpId();
      if (empIdStr == null) {
        _isLoading = false;
        notifyListeners();
        return false;
      }
      int empId = int.parse(empIdStr);

      final supabase = Supabase.instance.client;

      final authResponse = await supabase
          .from('app_collectors')
          .select()
          .eq('emp_id', empId)
          .eq('password', oldPassword)
          .maybeSingle();

      if (authResponse != null) {
        await supabase
            .from('app_collectors')
            .update({'password': newPassword}).eq('emp_id', empId);

        final db = await DatabaseHelper().database;
        await db.update(
          'employees',
          {'password': newPassword},
          where: 'id_emp = ?',
          whereArgs: [empId],
        );

        _isLoading = false;
        notifyListeners();
        return true;
      }
    } catch (e) {
      debugPrint('Change Password Error: $e');
    }

    _isLoading = false;
    notifyListeners();
    return false;
  }

  // --- دالة تسجيل الخروج ---
  Future<void> logout() async {
    await SecureStorageHelper.clearAll();
    notifyListeners();
  }

  // --- دالة فحص حالة الدخول عند فتح التطبيق (Splash Screen) ---
  Future<bool> checkLoginStatus() async {
    String? empId = await SecureStorageHelper.getEmpId();
    return empId != null;
  }
}