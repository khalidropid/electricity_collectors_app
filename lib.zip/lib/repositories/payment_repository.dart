import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:sqflite/sqflite.dart';
import 'package:electricity_collectors_app/models/payment.dart';
import 'package:electricity_collectors_app/services/payment_service.dart';
import 'package:electricity_collectors_app/database/database_helper.dart';

class PaymentRepository {
  final PaymentService _paymentService = PaymentService();
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<bool> savePayment(Payment payment) async {
    try {
      var connectivityResult = await (Connectivity().checkConnectivity());
      bool hasInternet = connectivityResult != ConnectivityResult.none;

      if (hasInternet) {
        try {
          bool isSubmitted = await _paymentService.submitPayment(payment);
          if (isSubmitted) {
            await _saveLocally(payment, 'synced');
            return true;
          }
        } catch (e) {
          await _saveLocally(payment, 'pending');
          return true;
        }
      } else {
        // لا يوجد نت: حفظ محلي كعملية معلقة
        await _saveLocally(payment, 'pending');
        return true;
      }
      return false;
    } catch (e) {
      throw Exception('خطأ في حفظ عملية التحصيل: $e');
    }
  }

  Future<void> _saveLocally(Payment payment, String status) async {
    final db = await _dbHelper.database;

    Map<String, dynamic> data = payment.toJson();
    data['status'] = status;

    if (data['id'] == 0) data.remove('id');

    await db.insert(
      'collections',
      data,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}
