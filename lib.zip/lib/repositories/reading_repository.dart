import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/customer.dart';

class CustomerProvider with ChangeNotifier {
  List<Customer> _searchResults = [];
  bool _isLoading = false;

  List<Customer> get searchResults => _searchResults;
  bool get isLoading => _isLoading;

  // جلب كافة المشتركين عند فتح الشاشة
  Future<void> loadCustomers() async {
    await search('');
  }

  // دالة مساعدة لتنقية الأرقام
  String _normalizeNumbers(String input) {
    const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
    const englishNumbers = '0123456789';
    String result = input;
    for (int i = 0; i < arabicNumbers.length; i++) {
      result = result.replaceAll(arabicNumbers[i], englishNumbers[i]);
    }
    return result;
  }

  // دالة البحث الشاملة والمباشرة من السيرفر
  Future<void> search(String query) async {
    _isLoading = true;
    notifyListeners();

    try {
      final supabase = Supabase.instance.client;
      
      // جلب البيانات من جدول customer (يمكنك تغيير اسم الجدول هنا إن كان مختلفاً في السيرفر)
      dynamic queryBuilder = supabase.from('customer').select();

      if (query.isNotEmpty) {
        String normalizedQuery = _normalizeNumbers(query);
        
        // البحث المرن عبر الأعمدة المحتملة (تأكد من مطابقتها لأعمدة جدولك في Supabase)
        queryBuilder = queryBuilder.or(
          'name_customer.ilike.%$normalizedQuery%,'
          'num_account.ilike.%$normalizedQuery%,'
          'num_phone.ilike.%$normalizedQuery%,'
          'num_addaad.ilike.%$normalizedQuery%'
        );
      } else {
        // جلب قائمة أولية واسعة (مثلاً أول 500 مشترك) لضمان ظهور البيانات فوراً
        queryBuilder = queryBuilder.limit(1000);
      }

      final List<dynamic> response = await queryBuilder;

      _searchResults = response.map((map) {
        return Customer(
          id: map['id_customer'] ?? map['id'] ?? 0,
          subscriberNo: (map['num_account'] ?? map['subscriber_no'] ?? '').toString(),
          name: map['name_customer'] ?? map['name'] ?? 'مشتري بدون اسم',
          phone: (map['num_phone'] ?? map['phone'] ?? '').toString(),
          meterNo: (map['num_addaad'] ?? map['meter_no'])?.toString(),
          areaId: map['id_state'] ?? map['area_id'] ?? 1,
          status: 'active',
          address: map['address_customer'] ?? map['address'] ?? '',
          arrears: 0.0,
          lastConsumption: 0,
          lastMonth: '',
        );
      }).toList();

    } catch (e) {
      debugPrint('خطأ في جلب أو بحث المشتركين من Supabase: $e');
      _searchResults = [];
    }

    _isLoading = false;
    notifyListeners();
  }
}