import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

// استدعاء الشاشات والمزودات
import '../features/change_password_screen.dart';
import '../features/dashboard_screen.dart';
import '../features/customer_search_screen.dart';
import '../features/reports_screen.dart';
import '../features/sync_screen.dart';
import '../features/settings_screen.dart';
import '../features/login_screen.dart';
import '../providers/auth_provider.dart';
import '../core/utils/secure_storage_helper.dart';
import '../features/modification_request_screen.dart'; // مسار ملف طلب التعديل

class AppDrawer extends StatefulWidget {
  const AppDrawer({super.key});

  @override
  State<AppDrawer> createState() => _AppDrawerState();
}

class _AppDrawerState extends State<AppDrawer> {
  String _collectorName = 'جاري التحميل...';
  int _currentEmpId = 1; // قيمة افتراضية

  @override
  void initState() {
    super.initState();
    _loadCollectorData();
  }

  Future<void> _loadCollectorData() async {
    String? name = await SecureStorageHelper.getCollectorName();
    String? empIdStr = await SecureStorageHelper.getEmpId();

    if (mounted) {
      setState(() {
        _collectorName = name ?? 'متحصل مجهول';
        if (empIdStr != null) {
          _currentEmpId = int.tryParse(empIdStr) ?? 1;
        }
      });
    }
  }

  // نافذة تأكيد الخروج
  void _showLogoutConfirmation() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.r)),
            title: Row(
              children: [
                const Icon(Icons.warning_amber_rounded,
                    color: Colors.red, size: 28),
                SizedBox(width: 10.w),
                Text('تأكيد الخروج',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 18.sp)),
              ],
            ),
            content: Text('هل أنت متأكد أنك تريد تسجيل الخروج من الحساب؟',
                style: TextStyle(fontSize: 15.sp)),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(),
                child: Text('إلغاء',
                    style: TextStyle(
                        color: Colors.grey.shade700,
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(dialogContext).pop();
                  _handleLogout();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.r)),
                ),
                child: Text('تسجيل الخروج',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 14.sp,
                        fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _handleLogout() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    await authProvider.logout();

    if (!mounted) return;

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => const LoginScreen()),
      (Route<dynamic> route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          UserAccountsDrawerHeader(
            decoration: const BoxDecoration(color: Color(0xFF1A5276)),
            accountName: Text(
              _collectorName,
              style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
            ),
            accountEmail: Text(
              'متصل - نظام المحصلين',
              style: TextStyle(fontSize: 14.sp, color: Colors.white70),
            ),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white.withOpacity(0.2),
              child: Icon(Icons.person, size: 40.w, color: Colors.white),
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _buildDrawerItem('الرئيسية', Icons.home, context),
                Divider(height: 10.h, color: Colors.grey.shade200),
                _buildDrawerItem('بحث المشتركين', Icons.search, context),
                _buildDrawerItem(
                    'طلب تعديل بيانات', Icons.edit_document, context),
                _buildDrawerItem('القراءات', Icons.speed, context),
                _buildDrawerItem(
                    'التحصيل', Icons.monetization_on_outlined, context),
                _buildDrawerItem('التقارير', Icons.bar_chart, context),
                _buildDrawerItem('المزامنة', Icons.sync, context),
                Divider(height: 20.h, color: Colors.grey.shade300),
                _buildDrawerItem('الإعدادات', Icons.settings, context),
                _buildDrawerItem(
                    'تغيير كلمة السر', Icons.lock_outline, context),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 15.h),
            child: ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: Text('تسجيل الخروج',
                  style: TextStyle(
                      fontSize: 15.sp,
                      color: Colors.red,
                      fontWeight: FontWeight.bold)),
              onTap: () {
                Navigator.pop(context);
                _showLogoutConfirmation();
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(String title, IconData icon, BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: const Color(0xFF1A5276), size: 24.w),
      title: Text(
        title,
        style: TextStyle(
            fontSize: 15.sp,
            fontWeight: FontWeight.bold,
            color: Colors.black87),
      ),
      onTap: () {
        Navigator.pop(context);

        if (title == 'الرئيسية') {
          Navigator.pushAndRemoveUntil(
            context,
            // 🌟 تمرير رقم الموظف هنا
            MaterialPageRoute(
                builder: (context) => DashboardScreen(empId: _currentEmpId)),
            (route) => false,
          );
        } else if (title == 'بحث المشتركين' ||
            title == 'القراءات' ||
            title == 'التحصيل') {
          // 🌟 تمرير رقم الموظف هنا
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      CustomerSearchScreen(empId: _currentEmpId)));
        } else if (title == 'طلب تعديل بيانات') {
          // 🌟 إضافة مسار شاشة طلب التعديل
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const ModificationRequestScreen()));
        } else if (title == 'التقارير') {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => const ReportsScreen()));
        } else if (title == 'المزامنة') {
          // 🌟 تمرير رقم الموظف هنا وإزالة الـ const
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => SyncScreen(empId: _currentEmpId)));
        } else if (title == 'الإعدادات') {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => const SettingsScreen()));
        } else if (title == 'تغيير كلمة السر') {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const ChangePasswordScreen()));
        }
      },
    );
  }
}
