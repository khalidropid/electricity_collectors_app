import 'package:dio/dio.dart';
import 'package:electricity_collectors_app/core/network/api_client.dart';
import 'package:electricity_collectors_app/models/reading.dart';

class ReadingService {
  final ApiClient _apiClient = ApiClient();

  // دالة لرفع قراءة جديدة للسيرفر
  Future<bool> submitReading(Reading reading) async {
    // ---------------------------------------------------------
    // كود محاكاة مؤقت لتجربة التطبيق قبل جاهزية السيرفر
    await Future.delayed(const Duration(seconds: 1)); // محاكاة سرعة النت
    return true; // نفترض أن الرفع نجح دائماً في هذه المرحلة
    // ---------------------------------------------------------

    /*
    // الكود الأصلي الخاص بك (سنفعله عندما يجهز السيرفر)
    try {
      final response = await _apiClient.dio.post(
        '/readings',
        data: reading.toJson(),
      );
      return response.statusCode == 200 || response.statusCode == 201;
    } on DioException catch (e) {
      throw Exception('فشل في رفع القراءة: ${e.message}');
    }
    */
  }
}
