import 'package:dio/dio.dart';
import '../core/network/api_client.dart';
import '../models/customer.dart';

class CustomerService {
  final ApiClient _apiClient = ApiClient();

  // دالة لجلب قائمة المشتركين بناءً على منطقة المتحصل
  Future<List<Customer>> getCustomers(int areaId) async {
    try {
      final response = await _apiClient.dio.get('/customers', queryParameters: {
        'area_id': areaId,
      });

      if (response.statusCode == 200) {
        // تحويل قائمة الـ JSON إلى قائمة من كائنات Customer
        List<dynamic> data = response.data['data'];
        return data.map((json) => Customer.fromJson(json)).toList();
      } else {
        throw Exception('فشل في جلب بيانات المشتركين');
      }
    } on DioException catch (e) {
      throw Exception('خطأ في الاتصال: ${e.message}');
    }
  }

  // دالة للبحث عن مشترك محدد (بالاسم أو الرقم)
  Future<List<Customer>> searchCustomers(String query) async {
    try {
      final response =
          await _apiClient.dio.get('/customers/search', queryParameters: {
        'q': query,
      });

      if (response.statusCode == 200) {
        List<dynamic> data = response.data['data'];
        return data.map((json) => Customer.fromJson(json)).toList();
      } else {
        throw Exception('فشل في البحث');
      }
    } on DioException catch (e) {
      throw Exception('خطأ في الاتصال: ${e.message}');
    }
  }
}
