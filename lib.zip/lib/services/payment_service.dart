import 'package:dio/dio.dart';
import 'package:electricity_collectors_app/core/network/api_client.dart';
import 'package:electricity_collectors_app/models/payment.dart';

class PaymentService {
  final ApiClient _apiClient = ApiClient();

  // دالة لرفع عملية تحصيل (دفع) جديدة
  Future<bool> submitPayment(Payment payment) async {
    try {
      final response = await _apiClient.dio.post(
        '/payments',
        data: payment.toJson(),
      );
      return response.statusCode == 200 || response.statusCode == 201;
    } on DioException catch (e) {
      throw Exception('فشل في رفع التحصيل: ${e.message}');
    }
  }
}
